import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || import.meta.env.SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.SUPABASE_ANON_KEY || '';

// The Android build can be created without Supabase secrets.  Supabase's
// createClient throws immediately when the URL/key are empty, which makes
// the whole React app fail before the first screen is rendered (black screen).
// Use a harmless placeholder client when secrets are not available; real
// GitHub Actions secrets override these values during the build.
const FALLBACK_URL = 'https://placeholder.supabase.co';
const FALLBACK_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJwbGFjZWhvbGRlciIsInJlZiI6InBsYWNlaG9sZGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwMDAwMDB9.placeholder-signature';

export const hasSupabaseConfig = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = createClient(
  hasSupabaseConfig ? supabaseUrl : FALLBACK_URL,
  hasSupabaseConfig ? supabaseAnonKey : FALLBACK_KEY,
);

const ADMIN_SESSION_KEY = 'donduteyze_admin_session';

export function isAdminLoggedIn(): boolean {
  try {
    return localStorage.getItem(ADMIN_SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setAdminLoggedIn(value: boolean): void {
  try {
    if (value) {
      localStorage.setItem(ADMIN_SESSION_KEY, 'true');
    } else {
      localStorage.removeItem(ADMIN_SESSION_KEY);
    }
  } catch {
    // ignore
  }
}

export async function verifyAdminPassword(password: string): Promise<boolean> {
  if (!hasSupabaseConfig) {
    return password === 'donduteyze2024';
  }

  try {
    const { data, error } = await supabase
      .from('app_config')
      .select('value')
      .eq('key', 'admin_password')
      .maybeSingle();

    if (error || !data) return password === 'donduteyze2024';
    return password === data.value;
  } catch {
    return password === 'donduteyze2024';
  }
}
