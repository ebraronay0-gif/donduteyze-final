const KEY='donduteyze_badges_v1';
export function getBadges(): string[]{try{return JSON.parse(localStorage.getItem(KEY)||'[]') as string[]}catch{return []}}
export function unlockBadge(id:string){const badges=getBadges();if(!badges.includes(id)){localStorage.setItem(KEY,JSON.stringify([...badges,id]));window.dispatchEvent(new Event('badges-updated'));}}
