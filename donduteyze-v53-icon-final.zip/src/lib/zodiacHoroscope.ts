import type { ZodiacSign } from './profile';

export interface ZodiacDailyReading {
  love: string;
  career: string;
  health: string;
  luckyNumber: number;
  luckyColor: string;
}

const LOVE_POOL: string[] = [
  'Aşk hayatında parlak bir gün seni bekliyor. Sevdiğinle aranızdaki bağ güçleniyor ve kalbiniz birbirine daha da yakınlaşıyor.',
  'İlişkinizde küçük bir anlaşmazlık olabilir, ancak sabırla aşılacak. Empatiyi elden bırakmayın.',
  'Bekarlar için sürpriz bir tanışma kapıda olabilir. Gözlerinizi açık tutun, kalbinizi hazır edin.',
  'Sevdiğinize küçük bir jest yapın. Büyük etkiler yaratacak ve aranızdaki sevgiyi besleyecek.',
  'Geçmiş bir aşk aklınıza gelebilir. Affedici olmak iç huzur getirecek.',
  'Romantik bir akşam yemeği planlayın. İlişkinize yeni bir soluk kazandırın.',
  'Sevdiğinizle açık iletişim kurma zamanı. İçtenliğin getireceği sıcaklığı hissedeceksiniz.',
  'Aşkta cesur adımlar atın. Beklemek yerine, hislerinizi paylaşma günü.',
  'Birinin size olan ilgisini fark edeceksiniz. Kalbinizin sesini dinleyin.',
  'İlişkinizde derinleşme zamanı. Yüzleşmekten korkmadığınız konuları paylaşın.',
  'Aşk hayatınızda yenilenme dönemi. Yeni bir sayfa açmak için kendinizi hazır hissedin.',
  'Sevdiğinizle geçireceğiniz sessiz anlar, en tatlı anılar olacak.',
];

const CAREER_POOL: string[] = [
  'Kariyerinizde beklenmedik bir fırsat kapınızı çalabilir. Hazırlıklı olun, cesur adım atın.',
  'İş yerindeki çabalarınız takdir görecek. Sabırlı olmaya devam edin, meyveler yakında toplanacak.',
  'Yeni bir proje veya görev üstlenme zamanı. Yeteneklerinizi konuşturun.',
  'Çalışma arkadaşlarınızla uyumlu bir gün. İş birliği size büyük başarı getirecek.',
  'Maddi konularda dikkatli olun. Bütçenizi gözden geçirmek için uygun bir gün.',
  'Kariyer hedeflerinizi yeniden değerlendirme zamanı. Yönünüzü netleştirin.',
  'Liderlik vasıflarınız öne çıkıyor. İnisiyatif alın, güven kazanın.',
  'Öğrenme ve gelişime açık olun. Bugün edindiğiniz bilgi, yarın işinize yarayacak.',
  'İş hayatında dengeyi koruyun. Aşırı yüklenmekten kaçının, dinlenmeye de vakit ayırın.',
  'Beklediğiniz haber bugün gelebilir. Sabırlı beklayışınızın karşılığını alacaksınız.',
  'Yaratıcı fikirlerinizi paylaşma günü. Toplantılarda söz almak size avantaj sağlayacak.',
  'Kariyerinizde bir dönüm noktası yaklaşabilir. Seçimlerinizi dikkatle yapın.',
];

const HEALTH_POOL: string[] = [
  'Enerjiniz yüksek, bedeniniz güçlü. Bugün spor veya doğa yürüyüşü ruhunuzu da besleyecek.',
  'Dinlenmeye ihtiyacınız var. Bedeninizi zorlamayın, bol su için ve erkenden uyuyun.',
  'Beslenmenize dikkat edin. Sebze ağırlıklı öğünler enerjinizi dengeleyecek.',
  'Stres yönetimi bugün önemli. Nefes egzersizleri veya meditasyon deneyin.',
  'Uyku düzeninizi gözden geçirin. Kaliteli uyku, yarınki enerjinizin temeli.',
  'Hareketli bir gün geçirin. Masrafsız egzersizler bile kendinizi iyi hissettirecek.',
  'Sırt veya boyun bölgenizde gerginlik olabilir. Esneme hareketleri yapın.',
  'Bağışıklığınızı güçlendirin. C vitamini ve taze meyveler gününüze renk katacak.',
  'Mental sağlığınıza özen gösterin. Sevdiğiniz bir aktiviteye vakit ayırın.',
  'Bugün bedeninizi şımartın. Sıcak bir duş veya rahatlatıcı bir banyo iyi gelecek.',
  'Dengeli bir yaşam tarzı seçin. Aşırılıklardan uzak durmak sağlığınızı koruyacak.',
  'Kendinizi yorgun hissedebilirsiniz. Kısa bir şekerleme günü kurtarabilir.',
];

const LUCKY_COLORS = [
  'Altın Sarı',
  'Gümüş',
  'Kırmızı',
  'Lacivert',
  'Yeşil',
  'Mor',
  'Turkuaz',
  'Bordo',
  'Pembe',
  'Beyaz',
  'Bakır',
  'Lila',
];

const ZODIAC_DATES: { sign: ZodiacSign; range: string; element: string; symbol: string }[] = [
  { sign: 'Koç', range: '21 Mar - 19 Nis', element: 'Ateş', symbol: '♈' },
  { sign: 'Boğa', range: '20 Nis - 20 May', element: 'Toprak', symbol: '♉' },
  { sign: 'İkizler', range: '21 May - 20 Haz', element: 'Hava', symbol: '♊' },
  { sign: 'Yengeç', range: '21 Haz - 22 Tem', element: 'Su', symbol: '♋' },
  { sign: 'Aslan', range: '23 Tem - 22 Ağu', element: 'Ateş', symbol: '♌' },
  { sign: 'Başak', range: '23 Ağu - 22 Eyl', element: 'Toprak', symbol: '♍' },
  { sign: 'Terazi', range: '23 Eyl - 22 Eki', element: 'Hava', symbol: '♎' },
  { sign: 'Akrep', range: '23 Eki - 21 Kas', element: 'Su', symbol: '♏' },
  { sign: 'Yay', range: '22 Kas - 21 Ara', element: 'Ateş', symbol: '♐' },
  { sign: 'Oğlak', range: '22 Ara - 19 Oca', element: 'Toprak', symbol: '♑' },
  { sign: 'Kova', range: '20 Oca - 18 Şub', element: 'Hava', symbol: '♒' },
  { sign: 'Balık', range: '19 Şub - 20 Mar', element: 'Su', symbol: '♓' },
];

export const ZODIAC_INFO = ZODIAC_DATES;

function seededRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function getDayOfYear(date: Date): number {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

function pickFromPool(pool: string[], seed: number): string {
  const index = Math.floor(seededRandom(seed) * pool.length);
  return pool[index];
}

export function getZodiacDailyReading(zodiac: ZodiacSign): ZodiacDailyReading {
  const today = new Date();
  const dayOfYear = getDayOfYear(today);
  const year = today.getFullYear();
  const signIndex = ZODIAC_DATES.findIndex((z) => z.sign === zodiac);

  return {
    love: pickFromPool(LOVE_POOL, dayOfYear + year + signIndex),
    career: pickFromPool(CAREER_POOL, dayOfYear + year + signIndex + 100),
    health: pickFromPool(HEALTH_POOL, dayOfYear + year + signIndex + 200),
    luckyNumber: Math.floor(seededRandom(dayOfYear + year + signIndex + 300) * 99) + 1,
    luckyColor: LUCKY_COLORS[Math.floor(seededRandom(dayOfYear + year + signIndex + 400) * LUCKY_COLORS.length)],
  };
}
