const DICE_KEY = 'fal_dice_play_date';

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function hasPlayedDiceToday(): boolean {
  try {
    return localStorage.getItem(DICE_KEY) === todayKey();
  } catch {
    return false;
  }
}

export function markDicePlayed(): void {
  try {
    localStorage.setItem(DICE_KEY, todayKey());
  } catch {
    // ignore
  }
}
