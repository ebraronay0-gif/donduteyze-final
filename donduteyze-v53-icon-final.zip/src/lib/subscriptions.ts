import { supabase, hasSupabaseConfig } from './supabase';
import { addCredits, getCredits, setCredits } from './credits';
import type { AuthUser } from './auth';
import { trackPurchase } from './analytics';

export type PlanId = 'weekly' | 'monthly' | 'yearly' | 'credits500' | 'credits200' | 'credits72';

interface PlanConfig {
  days: number;
  dailyCredits: number;
  adFree: boolean;
}

const PLAN_CONFIGS: Record<string, PlanConfig> = {
  weekly: { days: 7, dailyCredits: 20, adFree: true },
  monthly: { days: 30, dailyCredits: 20, adFree: true },
  yearly: { days: 365, dailyCredits: 20, adFree: true },
  credits500: { days: 30, dailyCredits: 0, adFree: true },
  credits200: { days: 15, dailyCredits: 0, adFree: true },
  credits72: { days: 7, dailyCredits: 0, adFree: true },
};

const SUB_CACHE_KEY = 'donduteyze_subscription';
const SUB_CACHE_TS_KEY = 'donduteyze_subscription_ts';

export interface SubscriptionInfo {
  active: boolean;
  plan: string;
  adFree: boolean;
  expiresAt: string | null;
  dailyCredits: number;
}

export async function purchasePlan(planId: PlanId, user: AuthUser): Promise<{ success: boolean; error: string | null }> {
  const config = PLAN_CONFIGS[planId];
  if (!config) return { success: false, error: 'Geçersiz paket.' };

  if (planId === 'credits500' || planId === 'credits200' || planId === 'credits72') {
    const creditAmount = planId === 'credits500' ? 500 : planId === 'credits200' ? 200 : 72;
    addCredits(creditAmount);
    window.dispatchEvent(new Event('credits-updated'));
    const packConfig = PLAN_CONFIGS[planId];
    const packExpires = new Date();
    packExpires.setDate(packExpires.getDate() + packConfig.days);
    cacheSubscription({ active: true, plan: planId, adFree: true, expiresAt: packExpires.toISOString(), dailyCredits: 0 });
    return { success: true, error: null };
  }

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + config.days);

  if (!hasSupabaseConfig) {
    return { success: false, error: 'Sunucu bağlantısı yapılandırılmamış.' };
  }

  // Guest purchases use a stable per-device anonymous Supabase identity.
  // The app may offer account creation later without blocking checkout.
  try {
    await supabase.from('app_users').upsert({ email: user.email, credits: getCredits() }, { onConflict: 'email', ignoreDuplicates: true });
  } catch { /* continue; subscription insert is authoritative */ }

  try {
    const { error } = await supabase.from('subscriptions').insert({
      user_email: user.email,
      plan: planId,
      ad_free: config.adFree,
      daily_credits: config.dailyCredits,
      starts_at: new Date().toISOString(),
      expires_at: expiresAt.toISOString(),
      active: true,
    });
    if (error) return { success: false, error: error.message };

    const subInfo: SubscriptionInfo = {
      active: true,
      plan: planId,
      adFree: config.adFree,
      expiresAt: expiresAt.toISOString(),
      dailyCredits: config.dailyCredits,
    };
    cacheSubscription(subInfo);
    triggerDailyCredits();
    trackPurchase(planId);
    return { success: true, error: null };
  } catch {
    return { success: false, error: 'Bağlantı hatası.' };
  }
}

export async function refreshSubscription(user: AuthUser | null): Promise<SubscriptionInfo | null> {
  if (!user) return null;
  if (!hasSupabaseConfig) return getCachedSubscription();

  const cached = getCachedSubscription();
  if (cached) return cached;

  try {
    const now = new Date().toISOString();
    const { data } = await supabase
      .from('subscriptions')
      .select('plan, ad_free, expires_at, daily_credits, active')
      .eq('user_email', user.email)
      .eq('active', true)
      .gt('expires_at', now)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      const info: SubscriptionInfo = {
        active: true,
        plan: data.plan,
        adFree: data.ad_free,
        expiresAt: data.expires_at,
        dailyCredits: data.daily_credits,
      };
      cacheSubscription(info);
      return info;
    }
    clearCachedSubscription();
    return null;
  } catch {
    return cached;
  }
}

export function getCachedSubscription(): SubscriptionInfo | null {
  try {
    const ts = localStorage.getItem(SUB_CACHE_TS_KEY);
    if (!ts) return null;
    const age = Date.now() - Number(ts);
    if (age > 5 * 60 * 1000) return null;
    const raw = localStorage.getItem(SUB_CACHE_KEY);
    if (!raw) return null;
    const info = JSON.parse(raw) as SubscriptionInfo;
    if (info.expiresAt && new Date(info.expiresAt) < new Date()) {
      clearCachedSubscription();
      return null;
    }
    return info;
  } catch {
    return null;
  }
}

function cacheSubscription(info: SubscriptionInfo): void {
  try {
    localStorage.setItem(SUB_CACHE_KEY, JSON.stringify(info));
    localStorage.setItem(SUB_CACHE_TS_KEY, String(Date.now()));
  } catch {
    // ignore
  }
}

function clearCachedSubscription(): void {
  try {
    localStorage.removeItem(SUB_CACHE_KEY);
    localStorage.removeItem(SUB_CACHE_TS_KEY);
  } catch {
    // ignore
  }
}

export function isAdFree(): boolean {
  const sub = getCachedSubscription();
  return !!sub?.adFree;
}

export function triggerDailyCredits(): void {
  if (!hasSupabaseConfig) return;

  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/daily-credits`;
  fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
  }).catch(() => {
    // fire and forget
  });
}

export async function syncCreditsFromSubscription(user: AuthUser): Promise<void> {
  const sub = await refreshSubscription(user);
  if (!sub) return;

  triggerDailyCredits();

  setTimeout(async () => {
    try {
      const { data } = await supabase
        .from('app_users')
        .select('credits')
        .eq('email', user.email)
        .maybeSingle();
      if (data && typeof data.credits === 'number') {
        const local = getCredits();
        if (data.credits !== local) {
          setCredits(data.credits);
          window.dispatchEvent(new Event('credits-updated'));
        }
      }
    } catch {
      // ignore
    }
  }, 2000);
}
