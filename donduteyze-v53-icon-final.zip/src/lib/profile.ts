export type ZodiacSign =
  | 'Koç'
  | 'Boğa'
  | 'İkizler'
  | 'Yengeç'
  | 'Aslan'
  | 'Başak'
  | 'Terazi'
  | 'Akrep'
  | 'Yay'
  | 'Oğlak'
  | 'Kova'
  | 'Balık';

export type MaritalStatus = 'Bekar' | 'Evli' | 'İlişkide' | 'Boşanmış' | 'Dul';

export interface UserProfile {
  fullName: string;
  age: number;
  zodiac: ZodiacSign;
  maritalStatus: MaritalStatus;
  createdAt: string;
}

export const ZODIAC_SIGNS: ZodiacSign[] = [
  'Koç',
  'Boğa',
  'İkizler',
  'Yengeç',
  'Aslan',
  'Başak',
  'Terazi',
  'Akrep',
  'Yay',
  'Oğlak',
  'Kova',
  'Balık',
];

export const MARITAL_STATUSES: MaritalStatus[] = [
  'Bekar',
  'Evli',
  'İlişkide',
  'Boşanmış',
  'Dul',
];

const PROFILE_KEY = 'fal_profile';

export function loadProfile(): UserProfile | null {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as UserProfile;
    if (
      parsed &&
      typeof parsed.fullName === 'string' &&
      typeof parsed.age === 'number' &&
      typeof parsed.zodiac === 'string' &&
      typeof parsed.maritalStatus === 'string'
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveProfile(profile: UserProfile): void {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}
