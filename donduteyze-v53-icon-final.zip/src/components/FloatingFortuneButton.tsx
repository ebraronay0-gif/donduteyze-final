import { Sparkles } from 'lucide-react';

interface FloatingFortuneButtonProps {
  onClick: () => void;
}

function FloatingFortuneButton({ onClick }: FloatingFortuneButtonProps) {
  return (
    <div className="pointer-events-none fixed bottom-[104px] left-0 right-0 z-40 flex justify-center">
      <button
        onClick={onClick}
        className="group pointer-events-auto relative flex items-center gap-1.5 overflow-hidden rounded-full border border-gold-400/50 bg-gradient-to-r from-mystic-700 via-mystic-800 to-mystic-900 px-4 py-2 shadow-[0_6px_24px_rgba(251,191,36,0.3)] transition-all duration-300 hover:scale-105 hover:shadow-[0_6px_32px_rgba(251,191,36,0.45)] active:scale-95 glow-border-gold"
      >
        {/* Shimmer sweep */}
        <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/20 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />

        <span className="relative flex h-5 w-5 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20">
          <Sparkles className="h-3 w-3 text-gold-300" />
        </span>
        <span className="relative font-display text-xs font-semibold tracking-wide text-gold-100">
          Yorumcularımıza Fal baktır
        </span>
      </button>
    </div>
  );
}

export default FloatingFortuneButton;
