import { useEffect, useState } from 'react';
import { Check, FileText, Shield, UserCheck } from 'lucide-react';
import LegalModal, { type LegalType } from '@/components/LegalModal';

interface LegalAcceptanceProps {
  onValidityChange?: (valid: boolean) => void;
  compact?: boolean;
}

export default function LegalAcceptance({ onValidityChange, compact = false }: LegalAcceptanceProps) {
  const [userAgreement, setUserAgreement] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [legalType, setLegalType] = useState<LegalType | null>(null);
  const valid = userAgreement && termsAccepted;
  useEffect(() => { onValidityChange?.(valid); }, [valid, onValidityChange]);

  const rows = [
    { checked: userAgreement, set: setUserAgreement, icon: UserCheck, type: 'user-agreement' as LegalType, label: 'Kullanıcı Sözleşmesi’ni okudum ve kabul ediyorum.' },
    { checked: termsAccepted, set: setTermsAccepted, icon: FileText, type: 'terms' as LegalType, label: 'Kullanım Şartları’nı okudum ve kabul ediyorum.' },
  ];

  return <>
    <div className={`space-y-2 rounded-xl border border-mystic-700/40 bg-night-900/35 ${compact ? 'p-3' : 'p-4'}`}>
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[.14em] text-gold-300/80">Yasal metinler</p>
      {rows.map(({ checked, set, icon: Icon, type }) => <div key={type} className="flex items-start gap-2">
        <button type="button" aria-pressed={checked} onClick={() => set(v => !v)} className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${checked ? 'border-gold-400 bg-gold-400/20 text-gold-300' : 'border-mystic-600 bg-night-700/60'}`}>
          {checked && <Check className="h-3.5 w-3.5" />}
        </button>
        <div className="text-xs leading-5 text-mystic-300"><button type="button" onClick={() => setLegalType(type)} className="inline-flex items-center gap-1 text-gold-200 underline-offset-2 hover:underline"><Icon className="h-3 w-3" />{type === 'terms' ? 'Kullanım Şartları' : 'Kullanıcı Sözleşmesi'}</button> <span>okudum ve kabul ediyorum.</span></div>
      </div>)}
      <div className="flex items-start gap-2">
        <div className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
        <div className="text-xs leading-5 text-mystic-300"><button type="button" onClick={() => setLegalType('privacy')} className="inline-flex items-center gap-1 text-gold-200 underline-offset-2 hover:underline"><Shield className="h-3 w-3" />Gizlilik ve KVKK Aydınlatma Metni</button> <span>bilgilendirme metnidir; ayrıca onay/rıza kutusuna bağlanmaz.</span></div>
      </div>
      {!valid && <p className="pt-1 text-[10px] text-amber-200/60">Devam etmek için Kullanıcı Sözleşmesi ve Kullanım Şartları kutucuklarını işaretleyin.</p>}
    </div>
    <LegalModal type={legalType} onClose={() => setLegalType(null)} />
  </>;
}
