import { NAV_TABS, type NavTabId } from '@/lib/navTabs';

interface Props {
  activeTab: NavTabId;
  onTabChange: (tab: NavTabId) => void;
  onSupportClick: () => void;
}

/** Premium, compact 6-item bottom navigation.
 * Only the home/Döndü Teyze item uses an image; all other items use clean labels
 * so the bar stays readable on small Android screens.
 */
function BottomNavBar({ activeTab, onTabChange, onSupportClick }: Props) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
      <div className="pointer-events-none absolute -top-10 inset-x-0 h-10 bg-gradient-to-t from-[#09031a] to-transparent" />
      <div className="mx-auto max-w-3xl px-1.5 pb-[calc(env(safe-area-inset-bottom)+6px)] pointer-events-auto">
        <div className="relative grid grid-cols-6 gap-1 rounded-[22px] border border-purple-300/25 bg-[#0c0419]/96 p-1.5 shadow-[0_-8px_35px_rgba(93,43,180,.28),0_0_30px_rgba(124,58,237,.15)] backdrop-blur-2xl">
          {NAV_TABS.map((tab) => {
            const active = activeTab === tab.id;
            const isHome = tab.id === 'home';
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => tab.id === 'support' ? onSupportClick() : onTabChange(tab.id)}
                className={`relative flex min-w-0 min-h-[58px] flex-col items-center justify-center rounded-[17px] px-0.5 py-1 transition-all duration-200 ${
                  active
                    ? 'bg-gradient-to-b from-purple-700/45 via-violet-700/20 to-transparent ring-1 ring-amber-300/30 shadow-[0_0_20px_rgba(168,85,247,.22)] scale-[1.02]'
                    : 'hover:bg-white/5'
                }`}
              >
                {isHome ? (
                  <>
                    <div className={`h-11 w-11 sm:h-12 sm:w-12 transition-transform ${active ? 'scale-110' : ''}`}>
                      <img src="/icon.png" alt="Döndü Teyze" className="h-full w-full object-contain drop-shadow-[0_5px_12px_rgba(251,191,36,.38)]" />
                    </div>
                    {/* No text under Döndü Teyze, as requested. */}
                  </>
                ) : (
                  <span className={`px-0.5 text-center text-[8px] sm:text-[9px] font-extrabold leading-tight tracking-tight ${active ? 'text-amber-200' : 'text-mystic-300'}`}>
                    {tab.label}
                  </span>
                )}
                {active && <span className="absolute bottom-0.5 h-0.5 w-7 rounded-full bg-amber-300 shadow-[0_0_9px_rgba(251,191,36,.9)]" />}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

export default BottomNavBar;
