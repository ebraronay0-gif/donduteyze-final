import { useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { AdMob, RewardAdPluginEvents } from '@capacitor-community/admob';
import { X, Play, Gift, AlertCircle, RefreshCw } from 'lucide-react';
import { ensureAdMobInitialized, getAdUnitId, USE_TEST_ADS } from '@/lib/ads';
import { trackAd } from '@/lib/analytics';

interface RewardedAdModalProps {
  open: boolean;
  onComplete: () => void;
  onClose: () => void;
  duration?: number;
  rewardLabel?: string;
}

function RewardedAdModal({ open, onComplete, onClose, duration = 5, rewardLabel = 'ödül' }: RewardedAdModalProps) {
  const [secondsLeft, setSecondsLeft] = useState(duration);
  const [completed, setCompleted] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [nativeError, setNativeError] = useState('');
  const [nativeLoading, setNativeLoading] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const timerRef = useRef<number | null>(null);
  const rewardedRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  const onCloseRef = useRef(onClose);

  useEffect(() => { onCompleteRef.current = onComplete; }, [onComplete]);
  useEffect(() => { onCloseRef.current = onClose; }, [onClose]);

  useEffect(() => {
    if (!open) {
      setSecondsLeft(duration);
      setCompleted(false);
      setShowConfirm(false);
      setNativeError('');
      setNativeLoading(false);
      setAttempt(0);
      rewardedRef.current = false;
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    if (!Capacitor.isNativePlatform()) {
      timerRef.current = window.setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            setCompleted(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }
  }, [open, duration]);

  useEffect(() => {
    if (!open || !Capacitor.isNativePlatform()) return;

    let cancelled = false;
    let rewardListener: { remove: () => Promise<void> } | null = null;
    let loadListener: { remove: () => Promise<void> } | null = null;
    let failedLoadListener: { remove: () => Promise<void> } | null = null;
    let failedShowListener: { remove: () => Promise<void> } | null = null;
    let dismissedListener: { remove: () => Promise<void> } | null = null;

    rewardedRef.current = false;
    setNativeLoading(true);
    setNativeError('');

    (async () => {
      try {
        // AdMob initialization must finish before preparing a rewarded ad.
        // Without this wait, opening a page immediately after app start can
        // race the native SDK and produce the generic 'Reklam açılamadı' screen.
        await ensureAdMobInitialized();
        if (cancelled) return;

        loadListener = await AdMob.addListener(RewardAdPluginEvents.Loaded, () => {
          if (!cancelled) setNativeLoading(false);
        });
        failedLoadListener = await AdMob.addListener(RewardAdPluginEvents.FailedToLoad, (error) => {
          console.error('Rewarded AdMob yüklenemedi:', error);
          if (!cancelled) {
            setNativeLoading(false);
            setNativeError('Ödüllü reklam yüklenemedi. İnternet bağlantısını kontrol edip tekrar deneyin.');
          }
        });
        failedShowListener = await AdMob.addListener(RewardAdPluginEvents.FailedToShow, (error) => {
          console.error('Rewarded AdMob gösterilemedi:', error);
          if (!cancelled) {
            setNativeLoading(false);
            setNativeError('Reklam hazırlandı fakat gösterilemedi. Lütfen tekrar deneyin.');
          }
        });
        dismissedListener = await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => {
          if (!cancelled && !rewardedRef.current) {
            setNativeLoading(false);
            setNativeError('Reklam tamamlanmadan kapatıldı; bu nedenle ödül verilmedi.');
          }
        });
        rewardListener = await AdMob.addListener(RewardAdPluginEvents.Rewarded, (rewardItem) => {
          if (cancelled || rewardedRef.current) return;
          const amount = Number(rewardItem?.amount ?? 0);
          if (amount <= 0) return;
          rewardedRef.current = true;
          trackAd('ad_rewarded');
          onCompleteRef.current();
        });

        await AdMob.prepareRewardVideoAd({
          adId: getAdUnitId('rewarded'),
          isTesting: USE_TEST_ADS,
          immersiveMode: true,
        });
        if (cancelled) return;

        setNativeLoading(false);
        const rewardItem = await AdMob.showRewardVideoAd();
        if (cancelled || rewardedRef.current) return;
        const amount = Number(rewardItem?.amount ?? 0);
        if (amount > 0) {
          rewardedRef.current = true;
          trackAd('ad_rewarded');
          onCompleteRef.current();
        } else {
          setNativeError('Reklam ödül vermeden kapandı. Lütfen tekrar deneyin.');
        }
      } catch (error) {
        console.error('Rewarded AdMob işlemi başarısız:', error);
        if (!cancelled) {
          setNativeLoading(false);
          setNativeError('Reklam yüklenemedi. Lütfen tekrar deneyin.');
        }
      }
    })();

    return () => {
      cancelled = true;
      void rewardListener?.remove();
      void loadListener?.remove();
      void failedLoadListener?.remove();
      void failedShowListener?.remove();
      void dismissedListener?.remove();
    };
  }, [open, attempt]);

  if (!open) return null;

  if (Capacitor.isNativePlatform()) {
    if (nativeLoading && !nativeError) {
      return (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#09031a]/90 px-5 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-[28px] border border-gold-400/30 bg-gradient-to-br from-[#261044] via-[#110723] to-[#080214] p-7 text-center shadow-[0_0_45px_rgba(168,85,247,.3)]">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold-300/40 bg-purple-900/30">
              <Play className="h-7 w-7 animate-pulse text-gold-200" />
            </div>
            <h3 className="mt-5 font-display text-xl text-gold-100">Reklam hazırlanıyor</h3>
            <p className="mt-2 text-xs leading-5 text-mystic-400">Ödüllü reklam yükleniyor. Hazır olduğunda otomatik açılacak.</p>
          </div>
        </div>
      );
    }

    if (nativeError) {
      return (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#09031a]/90 px-5 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-[28px] border border-rose-400/30 bg-gradient-to-br from-[#2a0c31] via-[#14061f] to-[#080214] p-6 text-center shadow-[0_0_45px_rgba(244,63,94,.18)]">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-rose-400/30 bg-rose-900/20"><AlertCircle className="h-7 w-7 text-rose-300" /></div>
            <h3 className="mt-4 font-display text-lg text-gold-100">Reklam açılamadı</h3>
            <p className="mt-2 text-xs leading-5 text-mystic-400">{nativeError}</p>
            <button onClick={() => setAttempt((v) => v + 1)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 text-sm font-semibold text-gold-100">
              <RefreshCw className="h-4 w-4" /> Tekrar Dene
            </button>
            <button onClick={onClose} className="mt-2 w-full rounded-2xl border border-white/10 px-4 py-3 text-xs text-mystic-400">Kapat</button>
          </div>
        </div>
      );
    }
    return null;
  }

  const progress = ((duration - secondsLeft) / duration) * 100;
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-night-900/90 px-4 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-mystic-600/40 bg-gradient-to-br from-night-700 to-night-900 shadow-2xl">
        <div className="flex items-center justify-between bg-mystic-800/60 px-4 py-2"><span className="text-xs font-medium text-mystic-300">Reklam önizlemesi</span><button onClick={() => { if (completed) { trackAd('ad_rewarded'); onCompleteRef.current(); } else setShowConfirm(true); }} className="flex h-7 w-7 items-center justify-center rounded-full text-mystic-400"><X className="h-4 w-4" /></button></div>
        <div className="relative flex min-h-[220px] flex-col items-center justify-center p-6">
          <div className="pointer-events-none absolute -top-10 left-1/2 h-32 w-32 -translate-x-1/2 -translate-y-0 rounded-full bg-gold-500/10 blur-3xl" />
          <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20"><Gift className="h-10 w-10 text-gold-300" /></div>
          <p className="mt-5 font-display text-lg font-semibold text-gold-100">{rewardLabel}</p>
          <p className="mt-2 text-center text-xs leading-relaxed text-mystic-400">Ödülü almak için reklamı tamamla.</p>
          <div className="mt-6 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-mystic-700/40"><div className="h-full rounded-full bg-gold-400 transition-all duration-1000" style={{ width: `${progress}%` }} /></div>
          <p className="mt-3 text-xs text-mystic-400">{completed ? 'Tamamlandı' : `${secondsLeft} saniye`}</p>
        </div>
        {showConfirm && <div className="border-t border-mystic-700/30 p-4"><p className="text-center text-xs text-mystic-300">Reklam tamamlanmadan çıkarsan ödül verilmez.</p><button onClick={() => setShowConfirm(false)} className="mt-3 w-full rounded-xl border border-gold-400/30 px-4 py-2 text-xs text-gold-100">Devam Et</button></div>}
      </div>
    </div>
  );
}

export default RewardedAdModal;
