import { Star } from 'lucide-react';

interface SparkleStarsProps {
  className?: string;
}

function SparkleStars({ className = '' }: SparkleStarsProps) {
  const stars = [
    { top: '-8px', left: '-8px', delay: '0s', size: 14 },
    { top: '-8px', right: '-8px', delay: '0.5s', size: 10 },
    { bottom: '-8px', left: '-8px', delay: '1s', size: 12 },
    { bottom: '-8px', right: '-8px', delay: '1.5s', size: 16 },
    { top: '50%', left: '-12px', delay: '0.8s', size: 8 },
    { top: '50%', right: '-12px', delay: '1.2s', size: 10 },
  ];

  return (
    <>
      {stars.map((star, i) => (
        <Star
          key={i}
          className={`star-sparkle absolute text-gold-300 animate-twinkle ${className}`}
          style={{
            top: star.top,
            left: star.left,
            right: star.right,
            bottom: star.bottom,
            width: star.size,
            height: star.size,
            animationDelay: star.delay,
          }}
          fill="currentColor"
        />
      ))}
    </>
  );
}

export default SparkleStars;
