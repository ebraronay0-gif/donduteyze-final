import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Gift, Play, CheckCircle2, Coins, Sparkles } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import BannerAd from '@/components/BannerAd';
import type { NavTabId } from '@/lib/navTabs';
import {
  AD_REWARD_CREDITS,
  MAX_EARN_ADS_PER_DAY,
  hasWatchedEarnAdToday,
  markEarnAdWatched,
  getEarnAdWatchedCount,
} from '@/lib/ads';
import { addCredits } from '@/lib/credits';

interface EarnPageProps {
  onNavigate: (tab: NavTabId) => void;
}

const AD_SLOTS = [
  { id: 0, name: 'Gizemli Ödül', visual: '🎁', icon: Play, gradient: 'from-rose-600/20 to-rose-950/40', glow: 'rgba(244, 63, 94, 0.3)', iconColor: 'text-rose-300' },
  { id: 1, name: 'Altın Şans', visual: '✨', icon: Play, gradient: 'from-sky-600/20 to-sky-950/40', glow: 'rgba(56, 189, 248, 0.3)', iconColor: 'text-sky-300' },
  { id: 2, name: 'Mor Hazine', visual: '💎', icon: Play, gradient: 'from-emerald-600/20 to-emerald-950/40', glow: 'rgba(16, 185, 129, 0.3)', iconColor: 'text-emerald-300' },
  { id: 3, name: 'Yıldız Ödülü', visual: '🌟', icon: Play, gradient: 'from-amber-600/20 to-amber-950/40', glow: 'rgba(217, 119, 6, 0.3)', iconColor: 'text-amber-300' },
];

function EarnPage({ onNavigate }: EarnPageProps) {
  const [watchedCount, setWatchedCount] = useState(0);
  const [activeSlot, setActiveSlot] = useState<number | null>(null);
  const [rewardedCredits, setRewardedCredits] = useState(false);

  const refresh = useCallback(() => {
    setWatchedCount(getEarnAdWatchedCount());
  }, []);

  useEffect(() => {
    refresh();
    const onUpdate = () => refresh();
    window.addEventListener('credits-updated', onUpdate);
    return () => window.removeEventListener('credits-updated', onUpdate);
  }, [refresh]);

  const handleAdComplete = () => {
    if (activeSlot === null) return;
    addCredits(AD_REWARD_CREDITS);
    markEarnAdWatched(activeSlot);
    window.dispatchEvent(new Event('credits-updated'));
    setActiveSlot(null);
    setRewardedCredits(true);
    setWatchedCount(getEarnAdWatchedCount());
    setTimeout(() => setRewardedCredits(false), 2500);
  };

  const handleAdClose = () => {
    setActiveSlot(null);
  };

  const allDone = watchedCount >= MAX_EARN_ADS_PER_DAY;

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-700/15 animate-glow-pulse" />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-mystic-700/40 bg-night-700/60 text-mystic-200 transition hover:border-gold-400/40 hover:text-gold-300"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Gift className="h-6 w-6 text-gold-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Kredi Kazan</h1>
          </div>
        </div>

        {/* Info card */}
        <div className="relative mb-6 overflow-hidden rounded-2xl border border-gold-400/30 bg-gradient-to-br from-night-700/70 to-night-800/80 p-5 backdrop-blur-sm">
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-gold-500/10 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-gold-400/20 bg-gold-900/20">
              <Coins className="h-6 w-6 text-gold-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-gold-100">Günlük Kredi Kazan</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-mystic-200">
                Aşağıdaki reklamları izleyerek günde toplam {AD_REWARD_CREDITS * MAX_EARN_ADS_PER_DAY} kredi kazanabilirsiniz. Her reklam günde sadece 1 kez izlenebilir.
              </p>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-4 flex items-center justify-between">
          <span className="text-sm text-mystic-300">Bugünkü ilerleme</span>
          <span className="rounded-full border border-gold-400/30 bg-gold-900/20 px-3 py-1 text-xs font-medium text-gold-200">
            {watchedCount} / {MAX_EARN_ADS_PER_DAY}
          </span>
        </div>

        {/* Ad grid */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {AD_SLOTS.map((slot) => {
            const watched = hasWatchedEarnAdToday(slot.id);
            const Icon = slot.icon;
            return (
              <button
                key={slot.id}
                onClick={() => !watched && !allDone && setActiveSlot(slot.id)}
                disabled={watched || allDone}
                className={`group relative aspect-[4/3] overflow-hidden rounded-xl border bg-gradient-to-br p-2 transition ${
                  watched
                    ? 'border-emerald-500/30 from-emerald-900/20 to-night-900/40'
                    : allDone
                    ? 'border-mystic-700/20 from-night-700/40 to-night-900/40 opacity-50'
                    : `${slot.gradient} border-mystic-700/40 hover:scale-[1.03] hover:border-gold-400/40`
                }`}
                style={!watched && !allDone ? { boxShadow: `0 4px 12px ${slot.glow}` } : undefined}
              >
                <div
                  className="pointer-events-none absolute -top-4 -right-4 h-14 w-14 rounded-full opacity-20 blur-2xl transition group-hover:opacity-40"
                  style={{ backgroundColor: slot.glow }}
                />
                <div className="relative flex h-full flex-col items-center justify-center gap-1"><div className="text-3xl drop-shadow-[0_8px_12px_rgba(0,0,0,.35)]">{slot.visual}</div>
                  {watched ? (
                    <>
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-emerald-400/30 bg-emerald-900/30">
                        <CheckCircle2 className="h-5 w-5 text-emerald-300" />
                      </div>
                      <span className="text-[11px] font-medium text-emerald-300">İzlendi</span>
                      <span className="text-[9px] text-emerald-400/60">+{AD_REWARD_CREDITS} kredi</span>
                    </>
                  ) : (
                    <>
                      <div
                        className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-gradient-to-br from-white/10 to-transparent transition-transform duration-500 group-hover:scale-110"
                        style={{ boxShadow: `0 4px 12px ${slot.glow}, inset 0 1px 1px rgba(255,255,255,0.12)` }}
                      >
                        <Icon className={`h-5 w-5 ${slot.iconColor}`} strokeWidth={1.5} />
                      </div>
                      <span className="text-[11px] font-medium text-mystic-200">{slot.name}</span>
                      <span className="flex items-center gap-1 text-[9px] text-gold-300">
                        <Coins className="h-2.5 w-2.5" />
                        +{AD_REWARD_CREDITS} kredi
                      </span>
                    </>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Banner Ad 1 */}
        <div className="mt-6">
          <BannerAd inline />
        </div>

        {/* All done message */}
        {allDone && (
          <div className="mt-6 flex items-center justify-center gap-2 rounded-xl border border-gold-400/30 bg-gold-900/10 px-4 py-3 text-center">
            <Sparkles className="h-4 w-4 text-gold-300" />
            <p className="text-sm text-gold-200">
              Bugünkü hakkınız doldu, yarın tekrar deneyin!
            </p>
          </div>
        )}

        {/* Reward toast */}
        {rewardedCredits && (
          <div className="fixed bottom-24 left-1/2 z-50 -translate-x-1/2 animate-fade-in-up">
            <div className="flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-900/40 px-5 py-3 backdrop-blur-sm">
              <Coins className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-sm font-semibold text-emerald-200">
                +{AD_REWARD_CREDITS} Kredi Kazanıldı!
              </span>
            </div>
          </div>
        )}

      </div>

      <RewardedAdModal
        open={activeSlot !== null}
        onComplete={handleAdComplete}
        onClose={handleAdClose}
        rewardLabel={`${AD_REWARD_CREDITS} Kredi`}
      />
    </div>
  );
}

export default EarnPage;
