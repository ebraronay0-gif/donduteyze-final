import { Hand } from 'lucide-react';
import PhotoFortunePage from '@/pages/PhotoFortunePage';
import type { NavTabId } from '@/lib/navTabs';

interface PalmFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const SLOTS = [
  { id: 0, label: 'Sağ El Fotoğrafı', hint: 'Sağ avucunuzun açık halini yükleyin' },
  { id: 1, label: 'Sol El Fotoğrafı', hint: 'Sol avucunuzun açık halini yükleyin' },
];

function PalmFortunePage({ onNavigate }: PalmFortunePageProps) {
  return (
    <PhotoFortunePage
      title="El Falı"
      introTitle="El Falına Bak"
      introText="Sağ ve sol el fotoğrafınızı yükleyin, yorumcularımız avuç içi çizgilerinizi okusun."
      icon={Hand}
      slots={SLOTS}
      accentColor="rose"
      fortuneType="palm"
      onNavigate={onNavigate}
    />
  );
}

export default PalmFortunePage;
