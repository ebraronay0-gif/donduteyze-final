import { useState } from 'react';
import { ArrowLeft, MessageCircle, Sparkles, Check, Shield, X, Crown } from 'lucide-react';
import StarField from '@/components/StarField';
import type { NavTabId } from '@/lib/navTabs';
import type { AuthUser } from '@/lib/auth';
import { LIVE_CHAT_PRICE, purchaseChatSession } from '@/lib/liveChat';
import { supabase, hasSupabaseConfig } from '@/lib/supabase';

interface LiveChatPurchasePageProps {
  onNavigate: (tab: NavTabId) => void;
  onOpenChat: () => void;
  authUser: AuthUser | null;
  onRequireAuth: () => void;
  isLoggedIn: boolean;
}

function LiveChatPurchasePage({ onNavigate, onOpenChat, authUser, onRequireAuth, isLoggedIn }: LiveChatPurchasePageProps) {
  const [purchasing, setPurchasing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleBuy = async () => {
    setPurchasing(true);
    setError(null);
    let buyer = authUser;
    if (!buyer && hasSupabaseConfig) {
      const { data, error: guestError } = await supabase.auth.signInAnonymously();
      if (!guestError && data.user) buyer = { id: data.user.id, email: data.user.email || '' };
    }
    if (!buyer) {
      setPurchasing(false);
      setError('Satın alma servisi şu anda hazır değil. Lütfen biraz sonra tekrar deneyin.');
      return;
    }
    const session = await purchaseChatSession(buyer);
    if (session) {
      setPurchasing(false);
      setSuccess(true);
      setTimeout(() => {
        onOpenChat();
      }, 2500);
    } else {
      setPurchasing(false);
      setError('Satın alma işlemi başarısız oldu. Lütfen tekrar deneyin.');
    }
  };

  const features = [
    'Gerçek falcılarla birebir sohbet',
    'Falını canlı olarak yorumlatma hakkı',
    'Sınırsız mesajlaşma (sohbet süresince)',
    'Sohbet kaydınız saklanır, kaldığınız yerden devam edersiniz',
  ];

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-gold-500/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-72 w-72 rounded-full bg-amber-600/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-amber-900/10 via-transparent to-amber-900/10" />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20 text-gold-200 transition hover:border-gold-400/60 hover:text-gold-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <MessageCircle className="h-6 w-6 text-gold-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Canlı Falcı Sohbeti</h1>
          </div>
        </div>

        {/* Hero card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-gold-400/40 bg-gradient-to-br from-amber-900/30 via-night-700/70 to-night-800/80 p-6 backdrop-blur-sm glow-border-gold" style={{ boxShadow: '0 0 16px rgba(251, 191, 36, 0.25), 0 0 32px rgba(251, 191, 36, 0.15)' }}>
          <div className="pointer-events-none absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
          <div className="relative text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
              <MessageCircle className="h-10 w-10 text-gold-300" />
            </div>
            <h2 className="font-display text-xl font-semibold text-gold-100">Falcılarımızla Canlı Sohbet</h2>
            <p className="mt-2 font-serif text-sm italic leading-relaxed text-gold-100/80">
              Profesyonel falcılarımızla birebir sohbet edin, falınızı canlı olarak yorumlatın.
            </p>
            <div className="mt-5 flex items-baseline justify-center gap-1">
              <span className="font-display text-5xl font-bold text-shimmer">{LIVE_CHAT_PRICE.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</span>
              <span className="text-lg text-gold-300/70">TL</span>
            </div>
            <p className="mt-1 text-xs text-gold-300/60">Tek seferlik ücret</p>
          </div>
        </div>

        {/* Features */}
        <div className="mb-8 space-y-3">
          {features.map((feature, i) => (
            <div key={i} className="flex items-center gap-3 rounded-xl border border-gold-400/20 bg-night-700/40 px-4 py-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/30">
                <Check className="h-4 w-4 text-gold-300" />
              </span>
              <span className="text-sm text-mystic-100">{feature}</span>
            </div>
          ))}
        </div>

        {/* Security note */}
        <div className="mb-6 flex items-start gap-3 rounded-xl border border-mystic-700/30 bg-night-700/40 p-4">
          <Shield className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
          <p className="text-xs leading-relaxed text-mystic-300">
            Ödeme güvenli şekilde işlenir. Sohbet oturumunuz sunucularımızda saklanır; internet kesilse veya uygulamayı kapatsanız bile, tekrar açtığınızda sohbete kaldığınız yerden devam edebilirsiniz.
          </p>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-sm text-rose-200">
            <X className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        {/* Buy button */}
        <button
          onClick={handleBuy}
          disabled={purchasing || success}
          className="group relative mb-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-gold-400/50 bg-gradient-to-r from-amber-600 via-amber-700 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50 glow-border-gold"
        >
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
          {purchasing ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-gold-200/30 border-t-gold-200" />
              <span className="font-display text-lg font-semibold text-gold-100">İşleniyor...</span>
            </>
          ) : success ? (
            <>
              <Check className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-lg font-semibold text-emerald-200">Satın Alındı</span>
            </>
          ) : (
            <>
              <Crown className="h-5 w-5 text-gold-300" />
              <span className="font-display text-lg font-semibold text-gold-100">Satın Al — {LIVE_CHAT_PRICE.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} TL</span>
            </>
          )}
        </button>

        <p className="text-center text-xs text-mystic-400">Giriş yapmadan da satın alabilirsin. İstersen daha sonra hesabını bağlayabilirsin.</p>

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Yorumcularımızın yorumları yalnızca eğlence amaçlıdır,
          profesyonel tavsiye niteliği taşımaz.
        </p>
      </div>

      {/* Success overlay */}
      {success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-gold-400/40 bg-gradient-to-br from-amber-900/40 via-night-700/90 to-night-800/95 p-8 text-center glow-border-gold animate-fade-in-up">
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
                <Check className="h-10 w-10 text-gold-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-gold-100">Satın Alma Başarılı</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Canlı sohbet sayfasına yönlendiriliyorsunuz...
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default LiveChatPurchasePage;
