import type { NavTabId } from '@/lib/navTabs';
import ThreeCardFortunePage from './ThreeCardFortunePage';
export default function TarotFortunePage({ onNavigate }: { onNavigate: (tab: NavTabId) => void }) {
  return <ThreeCardFortunePage kind="tarot" onNavigate={onNavigate} />;
}
