import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Dices, Coins, CheckCircle2, Info } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import { addCredits } from '@/lib/credits';
import { hasPlayedDiceToday, markDicePlayed } from '@/lib/dice';
import type { NavTabId } from '@/lib/navTabs';
import { unlockBadge } from '@/lib/badges';

interface DiceFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const PIPS: Record<number, [number, number][]> = {
  1: [[50, 50]],
  2: [[28, 28], [72, 72]],
  3: [[25, 25], [50, 50], [75, 75]],
  4: [[28, 28], [72, 28], [28, 72], [72, 72]],
  5: [[25, 25], [75, 25], [50, 50], [25, 75], [75, 75]],
  6: [[28, 22], [72, 22], [28, 50], [72, 50], [28, 78], [72, 78]],
};

function DieFace({ value, rolling }: { value: number; rolling: boolean }) {
  const pips = PIPS[value] || PIPS[1];
  return (
    <div
      className="relative h-28 w-28 rounded-2xl border-2 border-white/20 bg-gradient-to-br from-white to-mystic-100 shadow-xl"
      style={{
        boxShadow: '0 12px 30px rgba(0,0,0,0.4), inset 0 2px 4px rgba(255,255,255,0.6)',
        transform: rolling ? 'rotate(8deg) scale(0.95)' : 'rotate(0deg) scale(1)',
        transition: 'transform 0.3s ease',
      }}
    >
      <svg viewBox="0 0 100 100" className="h-full w-full">
        {pips.map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r="7" fill="#4c1d95" />
        ))}
      </svg>
    </div>
  );
}

function DiceFortunePage({ onNavigate }: DiceFortunePageProps) {
  const [value, setValue] = useState(1);
  const [rolling, setRolling] = useState(false);
  const [played, setPlayed] = useState(() => hasPlayedDiceToday());
  const [showLimit, setShowLimit] = useState(false);
  const [result, setResult] = useState<{ reward: number; dice: number } | null>(null);
  const [pendingReward, setPendingReward] = useState<{ reward: number; dice: number } | null>(null);
  const [shuffles, setShuffles] = useState(0);
  const shuffleInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const rollTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (shuffleInterval.current) clearInterval(shuffleInterval.current);
      if (rollTimeout.current) clearTimeout(rollTimeout.current);
    };
  }, []);

  const handleRoll = () => {
    if (rolling) return;
    if (played) {
      setShowLimit(true);
      return;
    }
    setRolling(true);
    setResult(null);

    let ticks = 0;
    shuffleInterval.current = setInterval(() => {
      setValue(Math.floor(Math.random() * 6) + 1);
      setShuffles((s) => s + 1);
      ticks += 1;
    }, 80);

    rollTimeout.current = setTimeout(() => {
      if (shuffleInterval.current) clearInterval(shuffleInterval.current);
      const finalValue = Math.floor(Math.random() * 6) + 1;
      setValue(finalValue);
      const reward = Math.floor(Math.random() * 5) + 1;
      setRolling(false);
      setPendingReward({ reward, dice: finalValue });
    }, 1800);
  };

  const handleCloseResult = () => {
    setResult(null);
    onNavigate('home');
  };

  const handleAdComplete = () => {
    if (!pendingReward) return;
    addCredits(pendingReward.reward); unlockBadge('lucky');
    markDicePlayed();
    setPlayed(true);
    setResult({ reward: pendingReward.reward, dice: pendingReward.dice });
    setPendingReward(null);
    window.dispatchEvent(new Event('credits-updated'));
  };

  const handleAdClose = () => {
    setPendingReward(null);
    onNavigate('home');
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-emerald-600/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-emerald-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-emerald-400/30 bg-emerald-900/20 text-emerald-200 transition hover:border-emerald-400/60 hover:text-emerald-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Dices className="h-6 w-6 text-emerald-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Zar Oyunu</h1>
          </div>
        </div>

        {/* Intro card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-900/30 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm" style={{ boxShadow: '0 0 12px rgba(16, 185, 129, 0.25), 0 0 24px rgba(16, 185, 129, 0.15), inset 0 0 10px rgba(16, 185, 129, 0.08)' }}>
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-emerald-500/20 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-emerald-400/30 bg-emerald-900/30" style={{ boxShadow: '0 6px 18px rgba(16, 185, 129, 0.35), inset 0 1px 1px rgba(255,255,255,0.15)' }}>
              <Coins className="h-6 w-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-emerald-100">Günlük Zar Atışı</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-emerald-100/80">
                Zarı at, çıkan sayıya göre 1 ila 5 kredi arası ödül kazan. Her gün bir kez ücretsiz oynayabilirsin.
              </p>
            </div>
          </div>
        </div>

        {/* Dice area */}
        <div className="mb-8 flex flex-col items-center">
          <div className="relative mb-8 flex h-44 w-full items-center justify-center rounded-2xl border border-emerald-700/30 bg-gradient-to-br from-night-700/60 to-night-900/80 backdrop-blur-sm" style={{ boxShadow: 'inset 0 0 20px rgba(16, 185, 129, 0.1)' }}>
            <div className="pointer-events-none absolute -top-8 left-1/2 h-24 w-24 -translate-x-1/2 rounded-full bg-emerald-500/15 blur-2xl" />
            <div className={rolling ? 'animate-pulse' : ''} key={shuffles}>
              <DieFace value={value} rolling={rolling} />
            </div>
          </div>

          {/* Roll button */}
          <button
            onClick={handleRoll}
            disabled={rolling || played}
            className="group relative flex w-full max-w-xs items-center justify-center gap-2 overflow-hidden rounded-2xl border border-emerald-400/50 bg-gradient-to-r from-emerald-700 via-emerald-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
            style={{ boxShadow: '0 0 12px rgba(16, 185, 129, 0.3), 0 0 24px rgba(16, 185, 129, 0.2)' }}
          >
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-emerald-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
            {rolling ? (
              <>
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-emerald-200/30 border-t-emerald-200" />
                <span className="font-display text-lg font-semibold text-emerald-100">Zar dönüyor...</span>
              </>
            ) : played ? (
              <>
                <Info className="h-5 w-5 text-emerald-300" />
                <span className="font-display text-lg font-semibold text-emerald-100">Bugün oynadınız</span>
              </>
            ) : (
              <>
                <Dices className="h-5 w-5 text-emerald-300" />
                <span className="font-display text-lg font-semibold text-emerald-100">Zar At</span>
              </>
            )}
          </button>

          {played && !rolling && (
            <p className="mt-4 text-center text-sm text-mystic-400">
              Bugünkü zar hakkınızı kullandınız, yarın tekrar bekleriz.
            </p>
          )}
        </div>

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Zar oyunu kredileri yalnızca uygulama içi kullanım içindir.
        </p>
      </div>

      {/* Daily limit modal */}
      {showLimit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in" onClick={() => setShowLimit(false)}>
          <div className="relative max-w-sm rounded-2xl border border-emerald-400/40 bg-gradient-to-br from-emerald-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(16, 185, 129, 0.3), 0 0 24px rgba(16, 185, 129, 0.2)' }} onClick={(e) => e.stopPropagation()}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-emerald-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-emerald-400/40 bg-emerald-900/30" style={{ boxShadow: '0 0 36px rgba(16, 185, 129, 0.5)' }}>
                <Info className="h-10 w-10 text-emerald-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-emerald-100">Bugünkü Zar Hakkınızı Kullandınız</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Zar oyunu her gün yalnızca bir kez oynanabilir. Yarın tekrar bekleriz!
            </p>
            <button
              onClick={() => setShowLimit(false)}
              className="mt-6 w-full rounded-xl border border-emerald-400/40 bg-emerald-900/30 px-4 py-3 font-display text-sm font-semibold text-emerald-100 transition hover:bg-emerald-800/40"
            >
              Tamam
            </button>
          </div>
        </div>
      )}

      <RewardedAdModal
        open={pendingReward !== null}
        onComplete={handleAdComplete}
        onClose={handleAdClose}
        rewardLabel={`${pendingReward?.reward ?? 0} Kredi`}
      />

      {/* Result modal */}
      {result && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-gold-400/40 bg-gradient-to-br from-gold-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(251, 191, 36, 0.3), 0 0 24px rgba(251, 191, 36, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
                <CheckCircle2 className="h-10 w-10 text-gold-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-gold-100">Tebrikler!</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Zar <span className="font-semibold text-emerald-200">{result.dice}</span> geldi ve <span className="font-semibold text-gold-200">{result.reward} kredi</span> kazandınız!
            </p>
            <button
              onClick={handleCloseResult}
              className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DiceFortunePage;
