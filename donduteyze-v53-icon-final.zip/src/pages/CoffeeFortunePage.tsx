import { Coffee } from 'lucide-react';
import PhotoFortunePage from '@/pages/PhotoFortunePage';
import type { NavTabId } from '@/lib/navTabs';

interface CoffeeFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const SLOTS = [
  { id: 0, label: 'Fincan Fotoğrafı', hint: 'Kahve fincanının açık halini yükleyin' },
  { id: 1, label: 'Tabak Fotoğrafı', hint: 'Fincan tabağındaki şekilleri yükleyin' },
];

function CoffeeFortunePage({ onNavigate }: CoffeeFortunePageProps) {
  return (
    <PhotoFortunePage
      title="Kahve Falı"
      introTitle="Kahve Falına Bak"
      introText="Fincan ve tabak fotoğrafınızı yükleyin, yorumcularımız sizin için gizli anlamları keşfetsin."
      icon={Coffee}
      slots={SLOTS}
      accentColor="amber"
      fortuneType="coffee"
      onNavigate={onNavigate}
    />
  );
}

export default CoffeeFortunePage;
