import { useMemo, useState } from 'react';
import { AlertCircle, ArrowLeft, CheckCircle2, Sparkles } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';
import { FORTUNE_COST, getCredits } from '@/lib/credits';

type FortuneKind = 'tarot' | 'angel' | 'katina';

interface Props {
  kind: FortuneKind;
  onNavigate: (tab: NavTabId) => void;
}

const DATA: Record<FortuneKind, {
  title: string;
  subtitle: string;
  instruction: string;
  prompt: (names: string[]) => string;
  cards: string[];
  accent: string;
  glow: string;
}> = {
  tarot: {
    title: 'TAROT FALI',
    subtitle: 'Kartlar seni çağırıyor...',
    instruction: 'Sezgilerine güven. 12 karttan 3 kart seçebilirsin.',
    prompt: (names) => `Tarot destesinden seçilen 3 kart: ${names.join(', ')}. Kartları geçmiş, şimdi ve gelecek sırasıyla yorumla; üç kartın ortak mesajını ve kullanıcının sorusuna yönelik güçlü bir kapanış mesajını ver.`,
    cards: ['Güneş','Ay','Yıldız','Sezgi','Kader','Bereket','Ateş','Akış','Cesaret','Aşk','Değişim','Ruh'],
    accent: 'amber',
    glow: 'rgba(251,191,36,.42)',
  },
  angel: {
    title: 'MELEK KARTLARI',
    subtitle: 'Melekler sana mesaj göndermek istiyor...',
    instruction: 'Sezgine odaklan. 12 karttan 3 melek kartı seç.',
    prompt: (names) => `Melek kartlarından seçilen 3 kart: ${names.join(', ')}. Her meleğin mesajını ayrı ayrı yorumla ve üç kartın ortak rehberlik mesajını sıcak, mistik ve kişisel bir dille ver.`,
    cards: ['Mikail','Cebrail','Rafael','Uriel','Haniel','Zadkiel','Sandalfon','Metatron','Yehuiyel','Jofiel','Azrael','Zofiel'],
    accent: 'violet',
    glow: 'rgba(167,139,250,.48)',
  },
  katina: {
    title: 'KATİNA FALI',
    subtitle: "Katina'nın gizemli kartları...",
    instruction: 'Sezgine güven. 12 karttan 3 Katina kartı seç.',
    prompt: (names) => `Katina destesinden seçilen 3 kart: ${names.join(', ')}. Kartların sembolik anlamlarını aşk, yol, kararlar ve yakın gelecek ekseninde yorumla; üç kartın ortak mesajını mistik ve kişisel bir dille ver.`,
    cards: ['Yolculuk','Yeni Başlangıç','Koruma','Sırlar','Kısmet','Nasip','Uyarı','Bağlantı','Karar','Zafer','Değişim','Destek'],
    accent: 'fuchsia',
    glow: 'rgba(232,121,249,.44)',
  },
};

const accentClasses: Record<string, { border: string; text: string; button: string; selected: string; soft: string }> = {
  amber: { border: 'border-amber-300/40', text: 'text-amber-100', button: 'from-[#7c2d12] via-[#5b21b6] to-[#3b0764]', selected: 'border-amber-200 shadow-[0_0_30px_rgba(251,191,36,.42)]', soft: 'bg-amber-300/10' },
  violet: { border: 'border-violet-300/40', text: 'text-violet-100', button: 'from-[#5b21b6] via-[#6d28d9] to-[#312e81]', selected: 'border-violet-100 shadow-[0_0_30px_rgba(167,139,250,.45)]', soft: 'bg-violet-300/10' },
  fuchsia: { border: 'border-fuchsia-300/40', text: 'text-fuchsia-100', button: 'from-[#86198f] via-[#6d28d9] to-[#3b0764]', selected: 'border-fuchsia-100 shadow-[0_0_30px_rgba(232,121,249,.42)]', soft: 'bg-fuchsia-300/10' },
};

function ThreeCardFortunePage({ kind, onNavigate }: Props) {
  const data = DATA[kind];
  const styles = accentClasses[data.accent];
  const [picks, setPicks] = useState<number[]>([]);
  const [showAd, setShowAd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedNames = useMemo(() => picks.map((i) => data.cards[i]), [picks, data.cards]);

  const cardPath = (index: number) => `/generated-cards/${kind}-${String(index + 1).padStart(2, '0')}.jpg`;
  const cardDepth = (index: number) => {
    const tilt = ((index % 3) - 1) * 2;
    return { transform: `perspective(900px) rotateY(${tilt}deg) translateZ(0)` };
  };

  const togglePick = (index: number) => {
    if (busy || success) return;
    setPicks((current) => {
      if (current.includes(index)) return current.filter((item) => item !== index);
      if (current.length >= 3) return current;
      return [...current, index];
    });
  };

  const submit = () => {
    if (picks.length !== 3 || busy) return;
    if (getCredits() < FORTUNE_COST) {
      setError(`${data.title.replace(' FALI', '')} falı için ${FORTUNE_COST} kredi gerekiyor.`);
      return;
    }
    setError(null);
    setShowAd(true);
  };

  const completeAd = async () => {
    setShowAd(false);
    setBusy(true);
    setError(null);
    const result = await submitFortune({
      fortuneType: kind,
      userInput: data.prompt(selectedNames),
    });
    setBusy(false);
    if (!result.success) {
      setError(result.error || 'Falınız gönderilemedi.');
      return;
    }
    setSuccess(true);
    window.setTimeout(() => onNavigate('history'), 1500);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05010e] pb-28 text-white">
      <StarField count={95} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_10%,rgba(124,58,237,.22),transparent_28%),radial-gradient(circle_at_84%_14%,rgba(251,191,36,.12),transparent_24%),radial-gradient(circle_at_50%_70%,rgba(76,29,149,.2),transparent_42%)]" />

      <main className="relative z-10 mx-auto max-w-3xl px-3 pb-8 pt-4 sm:px-5">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="mb-3 flex items-center gap-2 rounded-full border border-amber-300/35 bg-black/35 px-4 py-2 text-sm font-semibold text-amber-100 backdrop-blur"
        >
          <ArrowLeft className="h-4 w-4" /> Geri
        </button>

        <section className="relative overflow-hidden rounded-[30px] border border-amber-300/30 bg-gradient-to-b from-[#19082b] via-[#0b0317] to-[#04010a] shadow-[0_0_60px_rgba(124,58,237,.22)]">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-52 bg-gradient-to-b from-purple-700/10 to-transparent" />

          <header className="relative px-4 pb-4 pt-5 text-center sm:px-7">
            <div className="mx-auto mb-2 flex items-center justify-center gap-3 text-amber-300/80">
              <span className="h-px w-16 bg-gradient-to-r from-transparent to-amber-300/70" />
              <Sparkles className="h-5 w-5" />
              <span className="h-px w-16 bg-gradient-to-l from-transparent to-amber-300/70" />
            </div>
            <h1 className="font-display text-3xl font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-b from-amber-50 via-amber-300 to-amber-600 drop-shadow-[0_0_18px_rgba(251,191,36,.25)] sm:text-5xl">
              {data.title}
            </h1>
            <p className="mt-2 text-lg font-medium text-amber-50/90">{data.subtitle}</p>
            <p className="mx-auto mt-1 max-w-xl text-sm leading-relaxed text-purple-100/80 sm:text-base">{data.instruction}</p>
          </header>

          <div className="mx-3 mb-4 rounded-2xl border border-amber-300/25 bg-[#160724]/90 px-4 py-3 text-center shadow-[0_0_28px_rgba(124,58,237,.18)] sm:mx-5">
            <div className="flex items-center justify-center gap-2 text-amber-100">
              <Sparkles className="h-4 w-4" />
              <span className="font-display text-sm font-bold uppercase tracking-wider">12 karttan 3 kart seç</span>
              <Sparkles className="h-4 w-4" />
            </div>
          </div>

          <div className="border-y border-purple-300/15 bg-black/10 px-3 py-4 sm:px-5">
            <div className="mb-3 flex items-center justify-between px-1">
              <span className="font-display text-sm font-semibold text-amber-100">Seçilen Kartlar</span>
              <span className={`rounded-full border ${styles.border} ${styles.soft} px-3 py-1 text-xs font-bold ${styles.text}`}>{picks.length} / 3</span>
            </div>
            <div className="grid grid-cols-3 gap-3 sm:gap-5">
              {[0, 1, 2].map((slot) => {
                const index = picks[slot];
                return (
                  <div key={slot} className="relative aspect-[.66] overflow-hidden rounded-[20px] border border-dashed border-amber-300/20 bg-purple-950/30 p-1 shadow-[inset_0_0_22px_rgba(124,58,237,.18)]">
                    {index !== undefined ? (
                      <div className="h-full w-full rounded-[15px] bg-black/20 p-[2px] shadow-[0_10px_25px_rgba(0,0,0,.45)]"><img src={cardPath(index)} alt={data.cards[index]} className="h-full w-full rounded-[13px] object-cover" /></div>
                    ) : (
                      <div className="flex h-full flex-col items-center justify-center text-purple-300/35"><Sparkles className="h-7 w-7" /><span className="mt-2 text-[9px] font-bold uppercase tracking-wider">Kart {slot + 1}</span></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="px-3 py-5 sm:px-5 sm:py-6">
            <div className="mb-4 flex items-end justify-between px-1">
              <div>
                <h2 className="font-display text-lg font-bold text-amber-100">12 KARTTAN SEÇ</h2>
                <p className="mt-0.5 text-xs text-purple-200/65">Seçtiğin 3 kart fal yorumunda açılacak.</p>
              </div>
              <span className="text-xs font-semibold text-amber-200/75">{picks.length === 3 ? 'Seçim tamamlandı' : 'Sezgilerine güven'}</span>
            </div>

            <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 sm:gap-4">
              {data.cards.map((name, index) => {
                const picked = picks.includes(index);
                const order = picks.indexOf(index);
                return (
                  <button
                    key={name}
                    type="button"
                    onClick={() => togglePick(index)}
                    disabled={busy || success}
                    aria-label={`${index + 1}. ${name} kartını seç`}
                    className={`group relative overflow-hidden rounded-[20px] border bg-[#10051c]/80 p-1.5 transition-all duration-300 [perspective:1200px] ${picked ? styles.selected : 'border-purple-300/20 hover:-translate-y-1 hover:border-amber-300/55 hover:shadow-[0_16px_32px_rgba(124,58,237,.28)]'}`}
                  >
                    <div style={cardDepth(index)} className={`relative aspect-[.66] overflow-hidden rounded-[15px] border border-amber-200/15 transition-transform duration-300 [transform-style:preserve-3d] ${picked ? 'scale-[1.035] -translate-y-1' : 'group-hover:-translate-y-1'}`}>
                      <img src={cardPath(index)} alt={name} className="h-full w-full object-cover" />
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-white/5" />
                      <div className="pointer-events-none absolute inset-0 rounded-[15px] border border-white/10 shadow-[inset_0_0_18px_rgba(255,255,255,.16),inset_0_-18px_25px_rgba(0,0,0,.28),0_12px_24px_rgba(0,0,0,.38)]" />
                      <span className="absolute left-1/2 top-1.5 -translate-x-1/2 rounded-full border border-amber-200/70 bg-[#10051c]/90 px-2 py-0.5 text-[10px] font-bold text-amber-100 shadow-[0_0_12px_rgba(251,191,36,.3)]">{index + 1}</span>
                      {picked && <span className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-amber-300 px-2.5 py-1 text-[9px] font-black text-purple-950 shadow-[0_0_15px_rgba(251,191,36,.65)]">{order + 1}. SEÇİLDİ</span>}
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={submit}
              disabled={picks.length !== 3 || busy || success}
              className={`group relative mt-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-amber-300/55 bg-gradient-to-r ${styles.button} px-6 py-4 font-display text-xl font-bold text-amber-50 shadow-[0_0_30px_rgba(124,58,237,.24)] transition-all enabled:hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-40`}
            >
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
              {busy ? <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/25 border-t-white" /> : <Sparkles className="h-5 w-5" />}
              <span>{busy ? 'Falın hazırlanıyor...' : success ? 'Falın alındı' : 'FALIMA BAK'}</span>
              <span className="ml-1 rounded-full border border-amber-200/25 bg-black/20 px-2 py-0.5 text-xs">{FORTUNE_COST} KREDİ</span>
            </button>

            {error && <div className="mt-3 flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-950/30 px-3 py-2 text-xs text-rose-200"><AlertCircle className="h-4 w-4 shrink-0" />{error}</div>}
          </div>
        </section>

        <p className="mx-auto mt-4 max-w-md text-center text-[9px] leading-relaxed text-purple-300/35">Bu fal yalnızca eğlence amaçlıdır. Yorumlar gerçek bir öngörü veya profesyonel tavsiye niteliğinde değildir.</p>
      </main>

      <RewardedAdModal open={showAd} onComplete={completeAd} onClose={() => setShowAd(false)} rewardLabel={`${data.title} Yorumu`} />

      {success && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 px-6 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-[28px] border border-amber-300/35 bg-gradient-to-br from-[#2a0b4d] to-[#0c0318] p-7 text-center shadow-[0_0_50px_rgba(124,58,237,.35)]">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-300/40 bg-amber-300/10 shadow-[0_0_28px_rgba(251,191,36,.3)]"><CheckCircle2 className="h-9 w-9 text-amber-200" /></div>
            <h2 className="mt-4 font-display text-xl font-bold text-amber-100">Falın alındı ✨</h2>
            <p className="mt-2 text-sm leading-relaxed text-purple-100/75">Yorumun Fallarım bölümünde hazırlanıyor.</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default ThreeCardFortunePage;
