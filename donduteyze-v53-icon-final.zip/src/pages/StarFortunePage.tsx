import { useMemo, useState } from 'react';
import { ArrowLeft, CalendarDays, Clock3, MapPin, Sparkles, UserRound, WandSparkles } from 'lucide-react';
import StarField from '@/components/StarField';
import { submitFortune } from '@/lib/fortuneApi';
import { getCredits, FORTUNE_COST } from '@/lib/credits';
import type { NavTabId } from '@/lib/navTabs';

interface StarFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

function StarFortunePage({ onNavigate }: StarFortunePageProps) {
  const [fullName, setFullName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const now = new Date();
  const [readingDate, setReadingDate] = useState(now.toISOString().slice(0,10));
  const [readingTime, setReadingTime] = useState(now.toTimeString().slice(0,5));
  const [question, setQuestion] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const canSubmit = useMemo(
    () => fullName.trim() && birthDate && birthPlace.trim() && readingDate && readingTime && !busy,
    [fullName, birthDate, birthPlace, busy]
  );

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setError('');
    setMessage('');

    if (getCredits() < FORTUNE_COST) {
      setError(`Yıldız Falı için ${FORTUNE_COST} kredi gerekiyor.`);
      return;
    }

    setBusy(true);
    const userInput = JSON.stringify({
      name: fullName.trim(),
      birthDate,
      birthTime: birthTime || 'Bilinmiyor',
      birthPlace: birthPlace.trim(),
      interpretationDate: readingDate,
      interpretationTime: readingTime,
      question: question.trim() || 'Genel yıldız falımı yorumla.',
    });

    const result = await submitFortune({ fortuneType: 'star', userInput });
    setBusy(false);

    if (!result.success) {
      setError(result.error || 'Yıldız falın gönderilemedi.');
      return;
    }

    setMessage('Yıldız falın hazırlandı. Yorumun yaklaşık 4 dakika içinde Fallarım bölümünde görünecek. ✨');
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#09031a] pb-28">
      <StarField count={85} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_5%,rgba(126,34,206,0.34),transparent_32%),radial-gradient(circle_at_20%_55%,rgba(37,99,235,0.14),transparent_30%),radial-gradient(circle_at_90%_70%,rgba(168,85,247,0.16),transparent_30%)]" />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-5">
        <button
          onClick={() => onNavigate('home')}
          className="mb-5 flex items-center gap-2 rounded-full border border-mystic-500/30 bg-night-800/70 px-4 py-2 text-sm text-mystic-100"
        >
          <ArrowLeft className="h-4 w-4" /> Geri
        </button>

        <section className="relative overflow-hidden rounded-[28px] border border-gold-400/30 bg-gradient-to-b from-[#21103f]/95 via-[#120923]/95 to-[#09031a]/95 p-6 shadow-[0_0_35px_rgba(124,58,237,0.22)]">
          <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-purple-500/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -left-16 h-40 w-40 rounded-full bg-gold-500/10 blur-3xl" />

          <div className="relative text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full border border-gold-300/50 bg-gradient-to-br from-purple-700/70 to-indigo-950 shadow-[0_0_28px_rgba(168,85,247,0.45)]">
              <Sparkles className="h-10 w-10 text-gold-200" />
            </div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-300">Döndü Teyze'nin özel yorumu</p>
            <h1 className="mt-2 font-display text-4xl font-bold text-shimmer">YILDIZ FALI</h1>
            <p className="mx-auto mt-3 max-w-md font-serif text-sm leading-relaxed text-mystic-200">
              Doğum bilgilerini ver, yıldızların sana bugün ne fısıldadığını birlikte keşfedelim.
            </p>
          </div>

          <div className="relative mt-7 space-y-4">
            <label className="block">
              <span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><UserRound className="h-4 w-4" /> Ad Soyad</span>
              <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Adın ve soyadın" className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none placeholder:text-mystic-500 focus:border-gold-400/60" />
            </label>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><CalendarDays className="h-4 w-4" /> Doğum Tarihi</span>
                <input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none focus:border-gold-400/60" />
              </label>
              <label className="block">
                <span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><Clock3 className="h-4 w-4" /> Doğum Saati <span className="font-normal text-mystic-500">(isteğe bağlı)</span></span>
                <input type="time" value={birthTime} onChange={(e) => setBirthTime(e.target.value)} className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none focus:border-gold-400/60" />
              </label>
            </div>

            <label className="block">
              <span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><MapPin className="h-4 w-4" /> Doğum Yeri</span>
              <input value={birthPlace} onChange={(e) => setBirthPlace(e.target.value)} placeholder="Şehir / ülke" className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none placeholder:text-mystic-500 focus:border-gold-400/60" />
            </label>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className="block"><span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><CalendarDays className="h-4 w-4" /> Yorum Tarihi</span><input type="date" value={readingDate} onChange={(e)=>setReadingDate(e.target.value)} className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none focus:border-gold-400/60" /></label>
              <label className="block"><span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><Clock3 className="h-4 w-4" /> Yorum Saati</span><input type="time" value={readingTime} onChange={(e)=>setReadingTime(e.target.value)} className="w-full rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none focus:border-gold-400/60" /></label>
            </div>

            <label className="block">
              <span className="mb-2 flex items-center gap-2 text-xs font-semibold text-gold-200"><WandSparkles className="h-4 w-4" /> Özellikle merak ettiğin bir konu <span className="font-normal text-mystic-500">(isteğe bağlı)</span></span>
              <textarea value={question} onChange={(e) => setQuestion(e.target.value)} rows={3} maxLength={400} placeholder="Aşk, iş, para, gelecek veya genel olarak neyi merak ediyorsun?" className="w-full resize-none rounded-2xl border border-mystic-500/30 bg-night-900/70 px-4 py-3 text-sm text-white outline-none placeholder:text-mystic-500 focus:border-gold-400/60" />
            </label>

            {error && <div className="rounded-2xl border border-rose-500/30 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">{error}</div>}
            {message && <div className="rounded-2xl border border-emerald-400/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200">{message}</div>}

            <button
              onClick={handleSubmit}
              disabled={!canSubmit}
              className="w-full rounded-2xl border border-gold-300/50 bg-gradient-to-r from-purple-700 via-violet-600 to-indigo-700 px-5 py-4 font-display text-lg font-semibold text-gold-100 shadow-[0_0_24px_rgba(139,92,246,0.35)] transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {busy ? 'Yıldızlar yorumlanıyor…' : `YILDIZLARINA BAK · ${FORTUNE_COST} KREDİ`}
            </button>

            <p className="text-center text-[11px] text-mystic-500">Yorum tamamen eğlence amaçlıdır. Gerçeklikle hiçbir alakası yoktur.</p>
          </div>
        </section>
      </div>
    </div>
  );
}

export default StarFortunePage;
