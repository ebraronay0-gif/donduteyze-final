import { useMemo, useState } from 'react';
import { ArrowLeft, Award, Backpack, CalendarDays, Gift, Heart, Share2, Sparkles, Star, Trophy, Users, X } from 'lucide-react';
import type { NavTabId } from '@/lib/navTabs';
import { addCredits } from '@/lib/credits';
import RewardedAdModal from '@/components/RewardedAdModal';
import { getPet } from '@/lib/pet';

const CHEST_KEY='donduteyze_chest_v1';
const BADGE_KEY='donduteyze_badges_v1';
function today(){const d=new Date();return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`}
function loadChest(){try{return JSON.parse(localStorage.getItem(CHEST_KEY)||'null')||{date:'',opened:false,items:[]}}catch{return {date:'',opened:false,items:[]}}}
function loadBadges(){try{return JSON.parse(localStorage.getItem(BADGE_KEY)||'[]') as string[]}catch{return []}}

const badgeDefs=[
 {id:'first',name:'İlk Adım',icon:'🔮',desc:'İlk falını aç.'},
 {id:'diary',name:'Kalem Dostu',icon:'📖',desc:'Günlük yaz.'},
 {id:'pet',name:'Dost Bakıcısı',icon:'💜',desc:'Döndü Dostum ile ilgilen.'},
 {id:'streak',name:'Ateşli Seri',icon:'🔥',desc:'7 günlük seriye ulaş.'},
 {id:'lucky',name:'Şans Avcısı',icon:'🍀',desc:'Bir oyun ödülü kazan.'},
 {id:'explorer',name:'Evren Kaşifi',icon:'🌙',desc:'Gece oyununu keşfet.'},
];

function MyWorldPage({onNavigate}:{onNavigate:(tab:NavTabId)=>void}){
 const [chest,setChest]=useState(loadChest());
 const [badges]=useState(loadBadges());
 const [shareText,setShareText]=useState('');
 const [rewardOpen,setRewardOpen]=useState(false);
 const pet=getPet();
 const openChest=()=>{
   const d=today(); if(chest.date===d&&chest.opened)return;
   const pool=['🪙 +2 kredi','✨ +1 şans puanı','💜 Özel aşk enerjisi','🎁 Mor aksesuar kuponu'];
   const item=pool[Math.floor(Math.random()*pool.length)];
   const next={date:d,opened:true,items:[item,...(chest.items||[])]}; setChest(next); localStorage.setItem(CHEST_KEY,JSON.stringify(next));
   if(item.includes('kredi')) addCredits(2);
 };
 const shareFortune=async()=>{
   const text='🔮 Döndü Teyze bana özel bir fal sonucu hazırladı. Sen de kendi falını keşfet!';
   try{if(navigator.share){await navigator.share({title:'Döndü Teyze',text});}else{await navigator.clipboard?.writeText(text);setShareText('Mesaj panoya kopyalandı.');}}catch{}
 };
 const stats=useMemo(()=>({level:pet.level, xp:pet.xp, meals:pet.totalMeals}),[pet]);
 return <div className="relative min-h-screen overflow-hidden bg-[#09031a] pb-28 text-mystic-100">
  <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(168,85,247,.25),transparent_35%),radial-gradient(circle_at_100%_50%,rgba(251,191,36,.12),transparent_30%)]"/>
  <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
   <div className="mb-5 flex items-center gap-3"><button onClick={()=>onNavigate('home')} className="flex h-10 w-10 items-center justify-center rounded-full border border-mystic-700/40 bg-night-700/60"><ArrowLeft className="h-5 w-5"/></button><div><p className="text-[10px] uppercase tracking-[.25em] text-gold-300/70">Döndü Teyze evreni</p><h1 className="font-display text-2xl font-semibold text-shimmer">Benim Evrenim</h1></div></div>
   <section className="rounded-[28px] border border-gold-400/30 bg-gradient-to-br from-[#2a1047] via-[#16082d] to-[#0b0319] p-5 shadow-[0_0_35px_rgba(168,85,247,.18)]">
    <div className="flex items-center gap-4"><div className="flex h-20 w-20 items-center justify-center rounded-3xl border border-gold-300/40 bg-gradient-to-br from-purple-500/30 to-indigo-950 text-4xl shadow-[0_0_24px_rgba(168,85,247,.28)]">{pet.outfit==='gece'?'🌙':pet.outfit==='altin'?'👑':pet.outfit==='yildiz'?'✨':'🧿'}</div><div className="min-w-0 flex-1"><div className="flex items-center justify-between"><h2 className="font-display text-lg text-gold-100">Döndü Dostum</h2><span className="rounded-full border border-gold-300/30 px-2 py-1 text-[10px] text-gold-200">Lv.{stats.level}</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-black/30"><div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-amber-300" style={{width:`${Math.min(100,(stats.xp/30)*100)}%`}}/></div><p className="mt-2 text-[10px] text-mystic-400">{stats.xp}/30 XP · {stats.meals} toplam öğün</p></div></div>
    <div className="mt-4 grid grid-cols-3 gap-2"><div className="rounded-2xl border border-rose-400/20 bg-rose-900/10 p-3 text-center"><Heart className="mx-auto h-4 w-4 text-rose-300"/><p className="mt-1 text-[10px] text-mystic-300">Aşk</p><b className="text-sm text-rose-100">{pet.love}</b></div><div className="rounded-2xl border border-fuchsia-400/20 bg-fuchsia-900/10 p-3 text-center"><Sparkles className="mx-auto h-4 w-4 text-fuchsia-300"/><p className="mt-1 text-[10px] text-mystic-300">Mutluluk</p><b className="text-sm text-fuchsia-100">{pet.happiness}</b></div><div className="rounded-2xl border border-amber-400/20 bg-amber-900/10 p-3 text-center"><Star className="mx-auto h-4 w-4 text-amber-300"/><p className="mt-1 text-[10px] text-mystic-300">Sevgi</p><b className="text-sm text-amber-100">{pet.mood}</b></div></div>
   </section>

   <div className="mt-5 grid grid-cols-2 gap-3">
    <button onClick={openChest} className="rounded-[24px] border border-gold-400/30 bg-gradient-to-br from-[#32164f] to-[#120624] p-4 text-left"><Backpack className="h-6 w-6 text-gold-200"/><h3 className="mt-3 font-display text-base text-gold-100">Döndü Teyze'nin Çantası</h3><p className="mt-1 text-[10px] text-mystic-400">{chest.date===today()&&chest.opened?'Bugünkü çanta açıldı':'Bugünün sürprizini aç'}</p></button>
    <button onClick={()=>setRewardOpen(true)} className="rounded-[24px] border border-purple-400/30 bg-gradient-to-br from-[#24104b] to-[#0f0623] p-4 text-left"><Gift className="h-6 w-6 text-purple-200"/><h3 className="mt-3 font-display text-base text-gold-100">Sürpriz Sandığı</h3><p className="mt-1 text-[10px] text-mystic-400">Reklamı tamamla, küçük ödülü al.</p></button>
    <button onClick={shareFortune} className="rounded-[24px] border border-pink-400/25 bg-gradient-to-br from-[#3b123d] to-[#12051f] p-4 text-left"><Share2 className="h-6 w-6 text-pink-200"/><h3 className="mt-3 font-display text-base text-gold-100">Arkadaşına Fal Gönder</h3><p className="mt-1 text-[10px] text-mystic-400">Sonucunu paylaş, arkadaşını davet et.</p></button>
    <button onClick={()=>onNavigate('zodiac')} className="rounded-[24px] border border-indigo-400/25 bg-gradient-to-br from-[#171d52] to-[#08091e] p-4 text-left"><Sparkles className="h-6 w-6 text-indigo-200"/><h3 className="mt-3 font-display text-base text-gold-100">Burç Rehberi</h3><p className="mt-1 text-[10px] text-mystic-400">Aşk · Para · Kariyer · Şans</p></button>
   </div>

   <section className="mt-5 rounded-[24px] border border-gold-400/25 bg-night-800/70 p-4"><div className="flex items-center gap-2"><Trophy className="h-5 w-5 text-gold-300"/><h2 className="font-display text-lg text-gold-100">Rozet Koleksiyonum</h2></div><div className="mt-4 grid grid-cols-3 gap-2">{badgeDefs.map(b=><div key={b.id} className={`rounded-2xl border p-3 text-center ${badges.includes(b.id)?'border-gold-300/50 bg-gold-500/10':'border-white/10 bg-white/5 opacity-45'}`}><span className="text-2xl">{b.icon}</span><p className="mt-1 text-[10px] font-semibold text-gold-100">{b.name}</p><p className="mt-1 text-[8px] text-mystic-500">{b.desc}</p></div>)}</div></section>
   <section className="mt-5 rounded-[24px] border border-purple-400/25 bg-gradient-to-r from-purple-950/50 to-indigo-950/40 p-5"><div className="flex items-center gap-3"><Users className="h-6 w-6 text-purple-200"/><div><h2 className="font-display text-lg text-gold-100">Arkadaşını Davet Et</h2><p className="text-xs text-mystic-400">Falını paylaş; uygulamayı birlikte keşfedin.</p></div></div><button onClick={shareFortune} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-gold-300/40 bg-gold-500/10 py-3 text-sm font-semibold text-gold-100"><Share2 className="h-4 w-4"/> Paylaş</button>{shareText&&<p className="mt-2 text-center text-xs text-emerald-300">{shareText}</p>}</section>
   <section className="mt-5 rounded-[24px] border border-mystic-700/30 bg-night-800/60 p-5"><div className="flex items-center gap-3"><Award className="h-6 w-6 text-gold-300"/><div><h2 className="font-display text-lg text-gold-100">Günlük Seri</h2><p className="text-xs text-mystic-400">Her gün giriş yap, seri ve rozetlerini büyüt.</p></div></div><div className="mt-4"><p className="mb-2 text-[10px] uppercase tracking-[.2em] text-gold-300/70">Her günün hediyesi</p><div className="grid grid-cols-7 gap-1.5">{[1,2,3,4,5,6,7].map(n=><div key={n} className="rounded-xl border border-gold-300/15 bg-gold-500/5 p-2 text-center"><span className="text-base">{n===7?"🎁":"🎀"}</span><p className="mt-1 text-[7px] text-gold-200">+{n===7?3:1} kredi</p></div>)}</div></div><div className="mt-4 flex items-center gap-2">{[1,2,3,4,5,6,7].map(n=><div key={n} className="flex-1 text-center"><div className={`mx-auto flex h-8 w-8 items-center justify-center rounded-full border ${n<=Math.min(7,Math.max(1,pet.level))?'border-gold-300/50 bg-gold-500/15 text-gold-100':'border-white/10 bg-white/5 text-mystic-600'}`}>{n}</div><span className="mt-1 block text-[8px] text-mystic-500">{n}. gün</span></div>)}</div></section>
  </div>
  <RewardedAdModal open={rewardOpen} rewardLabel="Sandık Ödülü" onComplete={()=>{addCredits(2);setRewardOpen(false)}} onClose={()=>setRewardOpen(false)}/>
 </div>
}
export default MyWorldPage;
