import type { NavTabId } from '@/lib/navTabs';
import ThreeCardFortunePage from './ThreeCardFortunePage';
export default function AngelCardsFortunePage({ onNavigate }: { onNavigate: (tab: NavTabId) => void }) {
  return <ThreeCardFortunePage kind="angel" onNavigate={onNavigate} />;
}
