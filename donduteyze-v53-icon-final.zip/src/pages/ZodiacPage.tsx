import { useMemo, useState } from 'react';
import {
  Activity,
  Briefcase,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Coins,
  Heart,
  Moon,
  Palette,
  Sparkles,
  Star,
  Sun,
  Zap,
  Hash,
} from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import BannerAd from '@/components/BannerAd';
import type { ZodiacSign } from '@/lib/profile';
import { ZODIAC_INFO, getZodiacDailyReading } from '@/lib/zodiacHoroscope';

interface ZodiacPageProps {
  userZodiac?: ZodiacSign;
}

const ELEMENT_META: Record<string, { accent: string; soft: string; label: string; icon: string }> = {
  Ateş: { accent: '#fb7185', soft: 'rgba(244,63,94,.22)', label: 'Ateş', icon: '🔥' },
  Toprak: { accent: '#34d399', soft: 'rgba(16,185,129,.20)', label: 'Toprak', icon: '✦' },
  Hava: { accent: '#38bdf8', soft: 'rgba(56,189,248,.20)', label: 'Hava', icon: '◈' },
  Su: { accent: '#818cf8', soft: 'rgba(99,102,241,.22)', label: 'Su', icon: '◌' },
};

const ZODIAC_ART: Record<ZodiacSign, string> = {
  Koç: '♈', Boğa: '♉', İkizler: '♊', Yengeç: '♋', Aslan: '♌', Başak: '♍',
  Terazi: '♎', Akrep: '♏', Yay: '♐', Oğlak: '♑', Kova: '♒', Balık: '♓',
};

function seeded(seed: number) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

function percentFor(signIndex: number, offset: number) {
  return 62 + Math.floor(seeded(signIndex * 17 + offset + new Date().getDate()) * 31);
}

function Zodiac3DArt({ sign, large = false }: { sign: ZodiacSign; large?: boolean }) {
  const info = ZODIAC_INFO.find((z) => z.sign === sign)!;
  const meta = ELEMENT_META[info.element];
  return (
    <div
      className={`relative overflow-hidden rounded-[30px] border border-gold-400/35 bg-[#100521] ${large ? 'h-[320px] sm:h-[360px]' : 'h-full min-h-[150px]'}`}
      style={{ boxShadow: `0 18px 45px ${meta.soft}, inset 0 0 45px rgba(124,58,237,.18)` }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(168,85,247,.34),transparent_32%),radial-gradient(circle_at_15%_15%,rgba(251,191,36,.15),transparent_22%),linear-gradient(145deg,#30115f,#0c031a_68%,#16052f)]" />
      <div className="absolute -left-8 top-5 h-24 w-24 rounded-full bg-fuchsia-500/20 blur-3xl" />
      <div className="absolute -right-8 bottom-5 h-28 w-28 rounded-full bg-gold-400/10 blur-3xl" />
      {[...Array(10)].map((_, i) => (
        <span key={i} className="absolute h-1 w-1 rounded-full bg-gold-200 shadow-[0_0_8px_rgba(251,191,36,.9)]" style={{ left: `${8 + ((i * 29) % 84)}%`, top: `${12 + ((i * 37) % 72)}%`, opacity: .45 + (i % 3) * .18 }} />
      ))}
      <div className="absolute inset-5 rounded-[25px] border border-gold-300/15" />
      <div className="relative flex h-full flex-col items-center justify-center">
        <div className={`${large ? 'text-[138px]' : 'text-[72px]'} leading-none font-serif font-bold text-gold-100 drop-shadow-[0_8px_4px_rgba(0,0,0,.75)]`} style={{ textShadow: '0 0 20px rgba(192,132,252,.65), 0 5px 0 rgba(88,28,135,.8), 0 10px 18px rgba(0,0,0,.75)' }}>
          {ZODIAC_ART[sign]}
        </div>
        <div className="mt-2 rounded-full border border-gold-300/25 bg-black/30 px-4 py-1 text-[10px] uppercase tracking-[.28em] text-gold-200">{meta.icon} {meta.label}</div>
        {large && <div className="mt-3 font-display text-3xl font-semibold text-shimmer">{sign.toUpperCase()} BURCU</div>}
      </div>
    </div>
  );
}

function Metric({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative flex h-14 w-14 items-center justify-center rounded-full border border-gold-300/35 bg-[#130624]" style={{ boxShadow: `inset 0 0 18px rgba(168,85,247,.25), 0 0 15px rgba(251,191,36,.08)` }}>
        <div className="absolute inset-1 rounded-full border border-white/5" />
        <span className="text-gold-100">{icon}</span>
      </div>
      <span className="text-[10px] text-mystic-400">{label}</span>
      <span className="font-display text-sm text-gold-200">{value}%</span>
    </div>
  );
}

function ZodiacPage({ userZodiac }: ZodiacPageProps) {
  const [pendingZodiac, setPendingZodiac] = useState<ZodiacSign | null>(null);
  const [selected, setSelected] = useState<ZodiacSign>(userZodiac || 'Koç');

  const info = ZODIAC_INFO.find((z) => z.sign === selected)!;
  const reading = useMemo(() => getZodiacDailyReading(selected), [selected]);
  const index = ZODIAC_INFO.findIndex((z) => z.sign === selected);
  const love = percentFor(index, 11);
  const money = percentFor(index, 23);
  const health = percentFor(index, 37);
  const career = percentFor(index, 49);

  const today = new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
  const shortDaily = reading.career.slice(0, 115).replace(/\s+\S*$/, '') + '…';

  const selectZodiac = (sign: ZodiacSign) => setPendingZodiac(sign);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#07020f] pb-32">
      <StarField count={90} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_7%,rgba(124,58,237,.24),transparent_28%),radial-gradient(circle_at_0%_55%,rgba(91,33,182,.16),transparent_30%),linear-gradient(180deg,#0b0317,#08020f_60%,#05020b)]" />

      <main className="relative z-10 mx-auto max-w-5xl px-4 pb-8 pt-5 sm:px-6">
        <button onClick={() => history.back()} className="mb-4 flex items-center gap-2 rounded-full border border-gold-400/35 bg-[#12051f]/80 px-4 py-2 text-sm text-gold-100 shadow-[0_0_20px_rgba(251,191,36,.08)]">
          <ChevronLeft className="h-4 w-4" /> Geri
        </button>

        {/* Hero */}
        <section className="relative overflow-hidden rounded-[30px] border border-gold-400/35 bg-[#0d031b]/90 px-5 py-7 text-center shadow-[0_18px_60px_rgba(69,10,122,.25)] sm:px-8">
          <div className="absolute left-5 top-3 text-3xl text-gold-300/40">✦</div>
          <div className="absolute right-6 top-5 text-2xl text-purple-300/50">✧</div>
          <div className="absolute -left-16 bottom-0 h-32 w-32 rounded-full bg-purple-600/20 blur-3xl" />
          <div className="absolute -right-10 top-0 h-36 w-36 rounded-full bg-gold-500/10 blur-3xl" />
          <div className="mx-auto mb-3 flex w-fit items-center gap-2 rounded-full border border-gold-300/20 bg-gold-900/10 px-4 py-1.5 text-[10px] uppercase tracking-[.35em] text-gold-300/80"><Sun className="h-3.5 w-3.5" /> Gökyüzünün rehberi</div>
          <h1 className="font-display text-4xl font-semibold tracking-[.08em] text-shimmer sm:text-5xl">BURÇLARIM</h1>
          <p className="mx-auto mt-2 max-w-xl font-serif text-base text-mystic-200">Yıldızların rehberliğinde kendini keşfet</p>
          <div className="mx-auto mt-4 flex w-fit items-center gap-2 text-[10px] text-mystic-500"><Moon className="h-3.5 w-3.5 text-gold-300/60" /> {today} · Döndü Teyze'nin günlük gökyüzü yorumu</div>
        </section>

        {/* Zodiac selector */}
        <section className="mt-4 rounded-[26px] border border-gold-400/25 bg-[#0d031b]/85 p-3 shadow-[inset_0_0_35px_rgba(124,58,237,.12)]">
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {ZODIAC_INFO.map((z) => {
              const active = z.sign === selected;
              return (
                <button key={z.sign} onClick={() => selectZodiac(z.sign)} className={`min-w-[72px] rounded-2xl border px-2 py-2 text-center transition ${active ? 'border-gold-300/70 bg-gradient-to-b from-purple-700/60 to-gold-900/20 shadow-[0_0_22px_rgba(168,85,247,.25)]' : 'border-purple-400/15 bg-black/15'}`}>
                  <div className={`font-serif text-3xl ${active ? 'text-gold-100' : 'text-purple-200/75'}`} style={{ textShadow: active ? '0 0 15px rgba(251,191,36,.55)' : undefined }}>{z.symbol}</div>
                  <div className={`mt-1 text-[10px] font-bold ${active ? 'text-gold-100' : 'text-mystic-400'}`}>{z.sign.toUpperCase()}</div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Main dashboard */}
        <div className="mt-4 grid gap-4 lg:grid-cols-[1.02fr_.98fr]">
          <section className="luxury-section p-3 sm:p-4">
            <div className="mb-3 flex items-center justify-between px-2">
              <div><div className="text-[10px] uppercase tracking-[.3em] text-gold-300/70">Seçili burç</div><h2 className="mt-1 font-display text-2xl text-gold-100">{info.sign} Burcu</h2><p className="text-xs text-mystic-400">{info.range} · {info.element} elementi</p></div>
              <div className="rounded-full border border-gold-300/25 bg-gold-900/10 p-2"><Sparkles className="h-5 w-5 text-gold-300" /></div>
            </div>
            <Zodiac3DArt sign={selected} large />
            <div className="mt-3 grid grid-cols-4 gap-2 rounded-2xl border border-purple-300/15 bg-black/20 p-3 text-center">
              <div><div className="text-lg">🔥</div><p className="text-[9px] text-mystic-500">Element</p><b className="text-xs text-gold-100">{info.element}</b></div>
              <div><div className="text-lg">♂</div><p className="text-[9px] text-mystic-500">Yönetici</p><b className="text-xs text-gold-100">Mars</b></div>
              <div><div className="text-lg">◈</div><p className="text-[9px] text-mystic-500">Nitelik</p><b className="text-xs text-gold-100">Öncü</b></div>
              <div><div className="text-lg">🟣</div><p className="text-[9px] text-mystic-500">Renk</p><b className="text-xs text-gold-100">Mor</b></div>
            </div>
          </section>

          <div className="space-y-4">
            <section className="luxury-section p-5">
              <div className="mb-4 flex items-start justify-between gap-3"><div><div className="flex items-center gap-2 text-gold-200"><CalendarDays className="h-5 w-5" /><h2 className="font-display text-xl">GÜNLÜK YORUMUN</h2></div><p className="mt-1 text-xs text-mystic-500">{today}</p></div><span className="rounded-full border border-gold-300/20 bg-gold-900/10 px-2 py-1 text-[9px] text-gold-300">Bugün</span></div>
              <p className="font-serif text-sm leading-6 text-mystic-200">Bugün enerjin yüksek ve kararlılığın çevrendekilere ilham veriyor. Yeni başlangıçlar için güzel bir gün. {shortDaily}</p>
              <div className="mt-5 grid grid-cols-4 gap-2">
                <Metric label="Aşk" value={love} icon={<Heart className="h-5 w-5 text-rose-300" />} />
                <Metric label="Para" value={money} icon={<Coins className="h-5 w-5 text-emerald-300" />} />
                <Metric label="Sağlık" value={health} icon={<Activity className="h-5 w-5 text-sky-300" />} />
                <Metric label="Kariyer" value={career} icon={<Star className="h-5 w-5 text-gold-300" />} />
              </div>
            </section>

            <section className="luxury-section p-5">
              <div className="flex items-center gap-3"><div className="luxury-orb h-14 w-14 !rounded-2xl"><Moon className="h-6 w-6 text-gold-200" /></div><div><h3 className="font-display text-lg text-gold-100">UĞURLU SAATLERİN</h3><p className="text-2xl text-mystic-100">09:00 – 11:00</p></div></div>
              <div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-xl border border-purple-300/10 bg-black/20 p-3"><span className="text-[9px] text-mystic-500">Şanslı sayı</span><div className="mt-1 flex items-center gap-2 text-gold-100"><Hash className="h-4 w-4" /> {reading.luckyNumber}</div></div><div className="rounded-xl border border-purple-300/10 bg-black/20 p-3"><span className="text-[9px] text-mystic-500">Şanslı renk</span><div className="mt-1 flex items-center gap-2 text-gold-100"><Palette className="h-4 w-4" /> {reading.luckyColor}</div></div></div>
            </section>

            <section className="luxury-section p-5">
              <div className="flex items-center gap-2"><Zap className="h-5 w-5 text-fuchsia-300" /><h3 className="font-display text-lg text-gold-100">BUGÜNKÜ TAVSİYEN</h3></div>
              <p className="mt-3 font-serif text-sm leading-6 text-mystic-200">İç sesini dinle, doğru yolu o sana gösterecek. Bugün özellikle acele kararlar yerine sezgilerine alan aç.</p>
              <div className="mt-4 flex items-center gap-3 rounded-2xl border border-gold-300/15 bg-gradient-to-r from-purple-900/25 to-gold-900/10 p-3"><div className="text-3xl">🔮</div><span className="text-xs text-mystic-400">Gökyüzü enerjisini kendi ritminle kullan.</span></div>
            </section>
          </div>
        </div>

        {/* Weekly */}
        <section className="mt-4 grid gap-4 md:grid-cols-2">
          <div className="luxury-section p-5">
            <div className="flex items-center justify-between"><h3 className="font-display text-lg text-gold-100">HAFTALIK GÖRÜNÜM</h3><span className="rounded-full border border-gold-300/20 px-2 py-1 text-[9px] text-gold-300">Genel Enerji</span></div>
            <div className="mt-6 flex h-32 items-end gap-2 rounded-2xl border border-purple-300/10 bg-black/15 p-3">
              {[48,62,44,69,57,78,91].map((v, i) => <div key={i} className="flex flex-1 flex-col items-center gap-1"><div className="w-full rounded-t-xl bg-gradient-to-t from-purple-700/40 to-fuchsia-300/80 shadow-[0_0_12px_rgba(217,70,239,.25)]" style={{ height: `${v}%` }} /><span className="text-[8px] text-mystic-500">{['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][i]}</span></div>)}
            </div>
            <div className="mt-3 flex items-center justify-between text-xs text-mystic-400"><span>Yükselen enerji</span><b className="text-gold-200">72%</b></div>
          </div>

          <div className="luxury-section p-5">
            <h3 className="font-display text-lg text-gold-100">BU AY SANA ÖZEL</h3>
            <div className="mt-4 space-y-3">
              {[['🚪','Yeni Fırsatlar','Ayın ikinci yarısında önemli fırsatlar kapında.'],['⚖️','Duygusal Denge','Duygularını dengelemek ilişkilerinde huzur getirecek.'],['🧘','Kendine Zaman Ayır','Kendini ihmal etme, kendine vakit ayırmak iyi gelecek.']].map(([icon,title,text]) => <div key={title} className="flex items-center gap-3 rounded-2xl border border-purple-300/10 bg-black/15 p-3"><div className="text-2xl">{icon}</div><div><b className="text-sm text-gold-100">{title}</b><p className="mt-0.5 text-xs leading-5 text-mystic-400">{text}</p></div></div>)}
            </div>
          </div>
        </section>

        <div className="mt-5"><BannerAd inline size="large" /></div>
      </main>

      <RewardedAdModal open={pendingZodiac !== null} onComplete={() => { if (pendingZodiac) setSelected(pendingZodiac); setPendingZodiac(null); }} onClose={() => setPendingZodiac(null)} rewardLabel="Burç Yorumu" />
    </div>
  );
}

export default ZodiacPage;
