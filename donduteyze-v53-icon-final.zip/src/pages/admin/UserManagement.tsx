import { useState, useEffect, useCallback } from 'react';
import { Search, Coins, Save, Check, UserPlus, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AppUser {
  id: string;
  email: string;
  full_name: string | null;
  credits: number;
  zodiac: string | null;
  role: string;
  created_at: string;
}

function UserManagement() {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editCredits, setEditCredits] = useState(0);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', full_name: '', credits: 0, zodiac: '' });

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_users')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) setUsers(data as AppUser[]);
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const filtered = users.filter((u) =>
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    (u.full_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleEdit = (user: AppUser) => {
    setEditingId(user.id);
    setEditCredits(user.credits);
  };

  const handleSave = async (id: string) => {
    try {
      const { error } = await supabase
        .from('app_users')
        .update({ credits: editCredits })
        .eq('id', id);
      if (!error) {
        setUsers((prev) => prev.map((u) => u.id === id ? { ...u, credits: editCredits } : u));
        setSavedId(id);
        setEditingId(null);
        setTimeout(() => setSavedId(null), 2000);
      }
    } catch { /* ignore */ }
  };

  const handleAddUser = async () => {
    if (!newUser.email) return;
    try {
      const { data, error } = await supabase
        .from('app_users')
        .insert({
          email: newUser.email,
          full_name: newUser.full_name || null,
          credits: Number(newUser.credits) || 0,
          zodiac: newUser.zodiac || null,
        })
        .select()
        .maybeSingle();
      if (!error && data) {
        setUsers((prev) => [data as AppUser, ...prev]);
        setNewUser({ email: '', full_name: '', credits: 0, zodiac: '' });
        setShowAdd(false);
      }
    } catch { /* ignore */ }
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Kullanıcı Yönetimi</h1>
          <p className="text-sm text-mystic-400">{users.length} üye kayıtlı</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 rounded-xl border border-gold-400/40 bg-gold-900/20 px-4 py-2 text-sm font-medium text-gold-200 transition hover:bg-gold-900/40"
        >
          <UserPlus className="h-4 w-4" /> Kullanıcı Ekle
        </button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mystic-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="E-posta veya isim ara..."
          className="w-full rounded-xl border border-mystic-700/50 bg-night-800/60 py-2.5 pl-10 pr-4 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
        />
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center"><span className="h-6 w-6 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-mystic-700/40 bg-night-800/60">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-mystic-700/40 text-left text-xs text-mystic-400">
                <th className="px-4 py-3 font-medium">Kullanıcı</th>
                <th className="px-4 py-3 font-medium">Burç</th>
                <th className="px-4 py-3 font-medium">Kredi</th>
                <th className="px-4 py-3 font-medium">Kayıt</th>
                <th className="px-4 py-3 font-medium">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-mystic-500">Kullanıcı bulunamadı</td></tr>
              ) : (
                filtered.map((user) => (
                  <tr key={user.id} className="border-b border-mystic-700/20 transition hover:bg-night-700/30">
                    <td className="px-4 py-3">
                      <p className="font-medium text-mystic-100">{user.full_name || '—'}</p>
                      <p className="text-xs text-mystic-400">{user.email}</p>
                    </td>
                    <td className="px-4 py-3 text-mystic-300">{user.zodiac || '—'}</td>
                    <td className="px-4 py-3">
                      {editingId === user.id ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            value={editCredits}
                            onChange={(e) => setEditCredits(Number(e.target.value))}
                            className="w-20 rounded-lg border border-gold-400/40 bg-night-900/60 px-2 py-1 text-sm text-mystic-100 outline-none"
                          />
                        </div>
                      ) : (
                        <span className="flex items-center gap-1 text-gold-200">
                          <Coins className="h-3.5 w-3.5" /> {user.credits}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-mystic-400">
                      {new Date(user.created_at).toLocaleDateString('tr-TR')}
                    </td>
                    <td className="px-4 py-3">
                      {editingId === user.id ? (
                        <button
                          onClick={() => handleSave(user.id)}
                          className="flex items-center gap-1 rounded-lg border border-emerald-400/40 bg-emerald-900/20 px-3 py-1.5 text-xs text-emerald-200 transition hover:bg-emerald-900/40"
                        >
                          <Save className="h-3 w-3" /> Kaydet
                        </button>
                      ) : savedId === user.id ? (
                        <span className="flex items-center gap-1 text-xs text-emerald-300"><Check className="h-3 w-3" /> Kaydedildi</span>
                      ) : (
                        <button
                          onClick={() => handleEdit(user)}
                          className="rounded-lg border border-mystic-600/40 bg-night-700/40 px-3 py-1.5 text-xs text-mystic-200 transition hover:bg-night-700/70"
                        >
                          Düzenle
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Add user modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-4 backdrop-blur-sm" onClick={() => setShowAdd(false)}>
          <div className="w-full max-w-md rounded-2xl border border-gold-400/40 bg-gradient-to-br from-night-700/90 to-night-800/95 p-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-gold-100">Yeni Kullanıcı</h2>
              <button onClick={() => setShowAdd(false)} className="text-mystic-400 hover:text-mystic-200"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs text-mystic-300">E-posta *</label>
                <input type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-mystic-300">Ad Soyad</label>
                <input type="text" value={newUser.full_name} onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })}
                  className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs text-mystic-300">Kredi</label>
                  <input type="number" value={newUser.credits} onChange={(e) => setNewUser({ ...newUser, credits: Number(e.target.value) })}
                    className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50" />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-mystic-300">Burç</label>
                  <select value={newUser.zodiac} onChange={(e) => setNewUser({ ...newUser, zodiac: e.target.value })}
                    className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50">
                    <option value="">Seç</option>
                    {['Koç','Boğa','İkizler','Yengeç','Aslan','Başak','Terazi','Akrep','Yay','Oğlak','Kova','Balık'].map((z) => (
                      <option key={z} value={z}>{z}</option>
                    ))}
                  </select>
                </div>
              </div>
              <button onClick={handleAddUser}
                className="w-full rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:scale-[1.02]">
                Kullanıcı Ekle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserManagement;
