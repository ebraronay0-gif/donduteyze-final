import { useState } from 'react';
import { Sparkles, ChevronDown } from 'lucide-react';
import LegalAcceptance from '@/components/LegalAcceptance';
import StarField from '@/components/StarField';
import SparkleStars from '@/components/SparkleStars';
import {
  ZODIAC_SIGNS,
  MARITAL_STATUSES,
  saveProfile,
  type UserProfile,
  type ZodiacSign,
  type MaritalStatus,
} from '@/lib/profile';

interface OnboardingPageProps {
  onComplete: (profile: UserProfile) => void;
}

const FORTUNE_TELLER_IMG = '/icon.png';

function OnboardingPage({ onComplete }: OnboardingPageProps) {
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState('');
  const [zodiac, setZodiac] = useState<ZodiacSign | ''>('');
  const [maritalStatus, setMaritalStatus] = useState<MaritalStatus | ''>('');
  const [legalValid, setLegalValid] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  function validate(): boolean {
    const next: Record<string, string> = {};
    if (!fullName.trim()) next.fullName = 'Lütfen isim ve soyisminizi girin.';
    const ageNum = Number(age);
    if (!age || isNaN(ageNum) || ageNum < 18 || ageNum > 120)
      next.age = 'Yaş 18 ile 120 arasında olmalı.';
    if (!zodiac) next.zodiac = 'Lütfen burcunuzu seçin.';
    if (!maritalStatus) next.maritalStatus = 'Lütfen medeni halinizi seçin.';
    if (!legalValid) next.agreed = 'Devam etmek için Kullanıcı Sözleşmesi ve Kullanım Şartları kutucuklarını işaretlemelisiniz.';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const profile: UserProfile = {
      fullName: fullName.trim(),
      age: Number(age),
      zodiac: zodiac as ZodiacSign,
      maritalStatus: maritalStatus as MaritalStatus,
      createdAt: new Date().toISOString(),
    };
    saveProfile(profile);
    onComplete(profile);
  }

  const inputBase =
    'w-full rounded-xl border border-mystic-700/60 bg-night-700/60 px-4 py-2.5 text-mystic-100 placeholder-mystic-400/50 outline-none transition focus:border-gold-400 focus:glow-border-gold';

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900">
      <div className="pointer-events-none absolute inset-0">
        <img
          src={FORTUNE_TELLER_IMG}
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover object-center opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#09031a]/35 via-[#09031a]/65 to-[#09031a]/95" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_25%,rgba(126,34,206,0.30),transparent_42%)]" />
      </div>
      <StarField count={45} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-96 w-96 rounded-full bg-mystic-700/30 animate-glow-pulse" />
      <div className="pointer-events-none absolute -bottom-40 -right-40 h-96 w-96 rounded-full bg-gold-700/20 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-4 py-5">
        {/* Form card — immediately visible on first screen */}
        <div className="relative w-full max-w-md animate-fade-in-up lg:flex-1">
          <div className="relative rounded-3xl border border-mystic-600/50 bg-night-800/65 p-4 sm:p-5 backdrop-blur-xl glow-border">
            <SparkleStars />

            {/* Header */}
            <div className="mb-4 text-center">
              <div className="mx-auto mb-2 flex h-11 w-11 items-center justify-center rounded-full border border-gold-400/40 bg-night-700/60">
                <Sparkles className="h-5 w-5 text-gold-300" />
              </div>
              <h1 className="font-display text-2xl font-semibold text-shimmer">
                Kaderine Yolculuk
              </h1>
              <p className="mt-1 font-serif text-sm italic text-mystic-300">
                Geleceğini öğrenmek için bir adım at
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              {/* Full Name */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  İsim - Soyisim
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Adınız ve soyadınız"
                  className={inputBase}
                />
                {errors.fullName && (
                  <p className="mt-1 text-xs text-red-400">{errors.fullName}</p>
                )}
              </div>

              {/* Age */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Yaş
                </label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Yaşınız"
                  min={18}
                  max={120}
                  className={inputBase}
                />
                {errors.age && (
                  <p className="mt-1 text-xs text-red-400">{errors.age}</p>
                )}
              </div>

              {/* Zodiac */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Burç
                </label>
                <div className="relative">
                  <select
                    value={zodiac}
                    onChange={(e) => setZodiac(e.target.value as ZodiacSign)}
                    className={`${inputBase} appearance-none pr-10`}
                  >
                    <option value="" disabled>
                      Burcunuzu seçin
                    </option>
                    {ZODIAC_SIGNS.map((sign) => (
                      <option key={sign} value={sign}>
                        {sign}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-mystic-400" />
                </div>
                {errors.zodiac && (
                  <p className="mt-1 text-xs text-red-400">{errors.zodiac}</p>
                )}
              </div>

              {/* Marital Status */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-mystic-200">
                  Medeni Hal
                </label>
                <div className="relative">
                  <select
                    value={maritalStatus}
                    onChange={(e) => setMaritalStatus(e.target.value as MaritalStatus)}
                    className={`${inputBase} appearance-none pr-10`}
                  >
                    <option value="" disabled>
                      Medeni halinizi seçin
                    </option>
                    {MARITAL_STATUSES.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-mystic-400" />
                </div>
                {errors.maritalStatus && (
                  <p className="mt-1 text-xs text-red-400">{errors.maritalStatus}</p>
                )}
              </div>

              {/* Legal documents */}
              <LegalAcceptance onValidityChange={setLegalValid} />
              {errors.agreed && (
                <p className="text-xs text-red-400">{errors.agreed}</p>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting || !legalValid}
                className="group relative mt-2 w-full overflow-hidden rounded-xl border border-gold-400/50 bg-gradient-to-r from-mystic-700 to-mystic-900 px-6 py-3.5 font-display text-lg font-semibold text-gold-100 transition hover:from-mystic-600 hover:to-mystic-800 disabled:opacity-60 glow-border-gold"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  <Sparkles className="h-5 w-5 text-gold-300" />
                  {submitting ? 'Yıldızlar hizalanıyor...' : 'Falımı Gör'}
                </span>
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-gold-300/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OnboardingPage;
