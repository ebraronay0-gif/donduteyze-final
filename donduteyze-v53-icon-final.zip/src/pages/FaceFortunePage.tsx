import { useState, useRef, useCallback, useEffect } from 'react';
import { ArrowLeft, Smile, Upload, Sparkles, CheckCircle2, ImagePlus, AlertCircle, Camera, X } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';

interface FaceFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

function FaceFortunePage({ onNavigate }: FaceFortunePageProps) {
  const [photo, setPhoto] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showAd, setShowAd] = useState(false);
  const cameraRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = useCallback((file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setPhoto(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const openMenu = () => {
    if (photo) {
      setPhoto(null);
      return;
    }
    if (submitting || success) return;
    triggerCamera();
  };

  const triggerCamera = () => {
    cameraRef.current?.click();
    setShowMenu(false);
  };

  const triggerGallery = () => {
    galleryRef.current?.click();
    setShowMenu(false);
  };

  useEffect(() => {
    if (!showMenu) return;
    const close = () => setShowMenu(false);
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [showMenu]);

  const canSubmit = photo !== null;

  const handleSubmit = async () => {
    if (!canSubmit || submitting) return;
    setShowAd(true);
  };

  const handleAdComplete = async () => {
    setShowAd(false);
    setSubmitting(true);
    setError(null);
    const result = await submitFortune({
      fortuneType: 'face',
      imageData: photo ? [photo] : [],
    });
    if (result.success) {
      setSubmitting(false);
      setSuccess(true);
      setTimeout(() => {
        onNavigate('history');
      }, 4000);
    } else {
      setSubmitting(false);
      setError(result.error || 'Fal gönderilemedi.');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Blurred child face background */}
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-40"
        style={{ backgroundImage: 'url(/face-fortune-bg.webp)', filter: 'blur(8px) brightness(0.5)' }}
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-night-900/70 via-night-900/50 to-night-900/90" />

      {/* Sky-blue ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-sky-600/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-sky-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-sky-400/30 bg-sky-900/20 text-sky-200 transition hover:border-sky-400/60 hover:text-sky-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Smile className="h-6 w-6 text-sky-400" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Yüz Falı</h1>
          </div>
        </div>

        {/* Intro card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-sky-500/30 bg-gradient-to-br from-sky-900/30 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm" style={{ boxShadow: '0 0 12px rgba(14, 165, 233, 0.25), 0 0 24px rgba(14, 165, 233, 0.15), inset 0 0 10px rgba(14, 165, 233, 0.08)' }}>
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-sky-500/20 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-sky-400/30 bg-sky-900/30"
              style={{ boxShadow: '0 6px 18px rgba(14, 165, 233, 0.35), inset 0 1px 1px rgba(255,255,255,0.15)' }}
            >
              <Sparkles className="h-6 w-6 text-sky-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-sky-100">Yüz Falına Bak</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-sky-100/80">
                Yüz fotoğrafınızı yükleyin, yorumcularımız yüz hatlarınızdaki gizli anlamları keşfetsin.
              </p>
            </div>
          </div>
        </div>

        {/* Upload slot */}
        <div className="mb-8">
          <input
            ref={cameraRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files?.[0])}
          />
          <input
            ref={galleryRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files?.[0])}
          />
          <button
            onClick={openMenu}
            disabled={submitting || success}
            className="group relative mx-auto flex aspect-[3/4] w-full max-w-xs flex-col items-center justify-center overflow-hidden rounded-2xl border border-mystic-700/40 bg-gradient-to-br from-night-700/80 to-night-900/90 transition-all duration-300 hover:border-sky-400/50 disabled:cursor-not-allowed"
            style={{ boxShadow: photo ? '0 8px 28px rgba(14, 165, 233, 0.3)' : '0 4px 16px rgba(0,0,0,0.3)' }}
          >
            {/* Glow blob */}
            <div className="pointer-events-none absolute -top-10 -right-10 h-28 w-28 rounded-full bg-sky-600/20 opacity-30 blur-2xl transition-opacity duration-300 group-hover:opacity-60" />

            {photo ? (
              <>
                <img src={photo} alt="Yüz fotoğrafı" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-night-900/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <span className="rounded-full bg-night-900/70 px-3 py-1 text-xs font-medium text-sky-100 backdrop-blur-sm">
                    Yüz Fotoğrafı
                  </span>
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-sky-500/20 text-sky-300">
                    <CheckCircle2 className="h-4 w-4" />
                  </span>
                </div>
              </>
            ) : (
              <div className="relative flex flex-col items-center justify-center gap-3 px-4">
                {/* 3D Icon */}
                <div style={{ perspective: '600px' }}>
                  <div
                    className="transition-transform duration-500 group-hover:[transform:rotateY(15deg)_rotateX(-10deg)]"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <div
                      className="flex h-16 w-16 items-center justify-center rounded-2xl border border-sky-400/20 bg-gradient-to-br from-sky-900/30 to-transparent backdrop-blur-sm"
                      style={{
                        boxShadow: '0 8px 24px rgba(14, 165, 233, 0.25), inset 0 1px 1px rgba(255,255,255,0.12)',
                      }}
                    >
                      <ImagePlus className="h-8 w-8 text-sky-400" strokeWidth={1.5} />
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <p className="font-display text-sm font-semibold text-sky-100">Yüz Fotoğrafı</p>
                  <p className="mt-1 text-xs text-mystic-400">Net bir yüz fotoğrafı yükleyin</p>
                  <span className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-sky-400/20 bg-sky-900/20 px-3 py-1 text-xs text-sky-200">
                    <Camera className="h-3 w-3" />
                    Fotoğraf Ekle
                  </span>
                </div>
              </div>
            )}

            {/* Shimmer sweep */}
            <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-sky-300/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>

          <div className="mt-3 space-y-2">
            <button
              onClick={triggerCamera}
              disabled={submitting || success}
              className="flex w-full items-center justify-center gap-2 rounded-2xl border border-sky-400/50 bg-gradient-to-r from-sky-700 to-sky-800 px-5 py-3 font-display font-semibold text-sky-100"
            >
              <Camera className="h-5 w-5" />
              Fotoğraf Çek
            </button>
            <button
              onClick={triggerGallery}
              disabled={submitting || success}
              className="flex w-full items-center justify-center gap-2 rounded-2xl border border-purple-400/35 bg-purple-950/50 px-5 py-3 font-display font-semibold text-purple-100"
            >
              <Upload className="h-5 w-5" />
              Fotoğraf Yükle
            </button>
          </div>
        </div>

        {/* Submit button */}
        {canSubmit && (
        <button
          onClick={handleSubmit}
          disabled={submitting || success}
          className="group relative mb-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-sky-400/50 bg-gradient-to-r from-sky-700 via-sky-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
          style={{ boxShadow: '0 0 12px rgba(14, 165, 233, 0.3), 0 0 24px rgba(14, 165, 233, 0.2)' }}
        >
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-sky-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
          {submitting ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-sky-200/30 border-t-sky-200" />
              <span className="font-display text-lg font-semibold text-sky-100">Yorumculara iletiliyor...</span>
            </>
          ) : success ? (
            <>
              <CheckCircle2 className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-lg font-semibold text-emerald-200">İletildi</span>
            </>
          ) : (
            <>
              <Smile className="h-5 w-5 text-sky-300" />
              <span className="font-display text-lg font-semibold text-sky-100">Falımı Bak</span>
            </>
          )}
        </button>
        )}

        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-sm text-rose-200">
            <AlertCircle className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Yorumcularımızın yorumları yalnızca eğlence amaçlıdır,
          profesyonel tavsiye niteliği taşımaz. Sonuçlar gerçek hayat olaylarını etkilemez veya
          öngörmez.
        </p>
      </div>

      <RewardedAdModal
        open={showAd}
        onComplete={handleAdComplete}
        onClose={() => setShowAd(false)}
        rewardLabel="Fal Yorumu"
      />

      {/* Success overlay */}
      {success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-sky-400/40 bg-gradient-to-br from-sky-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(14, 165, 233, 0.3), 0 0 24px rgba(14, 165, 233, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-sky-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div
                className="flex h-20 w-20 items-center justify-center rounded-full border border-sky-400/40 bg-sky-900/30"
                style={{ boxShadow: '0 0 36px rgba(14, 165, 233, 0.5)' }}
              >
                <CheckCircle2 className="h-10 w-10 text-sky-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-sky-100">Falınız İletildi</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Falınız yıldızlara iletildi. Fallarım sayfasından takip edebilirsiniz.
            </p>
            <p className="mt-4 text-xs text-mystic-500">Fallarım sayfasına yönlendiriliyorsunuz...</p>
          </div>
        </div>
      )}

      {/* Photo action sheet */}
      {showMenu && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-night-900/70 px-4 pb-6 backdrop-blur-sm animate-fade-in sm:items-center sm:pb-0"
          onClick={() => setShowMenu(false)}
        >
          <div
            className="relative w-full max-w-sm overflow-hidden rounded-2xl border border-sky-500/40 bg-gradient-to-br from-night-700/95 to-night-800/98 p-2 shadow-2xl animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-3 py-2">
              <span className="font-display text-sm font-semibold text-sky-100">Yüz Fotoğrafı</span>
              <button
                onClick={() => setShowMenu(false)}
                className="flex h-8 w-8 items-center justify-center rounded-full text-mystic-400 transition hover:text-mystic-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-1.5">
              <button
                onClick={triggerCamera}
                className="flex w-full items-center gap-3 rounded-xl border border-sky-400/20 bg-sky-900/20 px-4 py-3.5 text-left transition hover:bg-sky-800/30"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-sky-400/30 bg-sky-900/30">
                  <Camera className="h-5 w-5 text-sky-300" />
                </div>
                <div>
                  <p className="font-display text-sm font-semibold text-sky-100">Fotoğraf Çek</p>
                  <p className="text-xs text-mystic-400">Kamerayı aç ve anında çek</p>
                </div>
              </button>
              <button
                onClick={triggerGallery}
                className="flex w-full items-center gap-3 rounded-xl border border-mystic-700/40 bg-night-900/40 px-4 py-3.5 text-left transition hover:bg-night-700/50"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-mystic-700/40 bg-night-900/40">
                  <Upload className="h-5 w-5 text-mystic-300" />
                </div>
                <div>
                  <p className="font-display text-sm font-semibold text-mystic-100">Fotoğraf Yükle</p>
                  <p className="text-xs text-mystic-400">Galeriden bir fotoğraf seç</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default FaceFortunePage;
