# V26 – Ana Sayfa & Su Falı Görsel Yenileme

- Ana sayfa kart grid'i, referanstaki 3D/kozmik mor-altın görsel dile yaklaştırıldı.
- Kartlara derinlik, parlama, hover/press ve altın fiyat rozeti efektleri eklendi.
- Bugünün Köşesi 3D görünümlü Burç / Aşk / Kariyer küreleri ve daha premium panel düzeniyle yenilendi.
- Su Falı sayfası referanstaki premium mor-altın/cam görünümüne taşındı.
- Su Falı kasesi için 3D su/ritüel görseli eklendi; parmakla karıştırma etkileşimi korunarak görsel hareket efekti bağlandı.
- Su Falı reklam -> yapay zekâ gönderimi -> Fallarım akışı korunmuştur.
- Android launcher icon için yeni güvenli alanlı Döndü Teyze ikonu üretildi ve GitHub Android workflow'unda zorunlu ikon olarak bağlandı.
- Sürüm 1.0.26 / Android versionCode 26.
