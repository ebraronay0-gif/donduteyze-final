# V25 — AdMob rewarded ad reliability fix

- Fixed a startup race where rewarded ads could be requested before the native AdMob SDK finished initializing.
- Debug APKs now use Google official rewarded test ads by default, so ad flow can be verified reliably without risking live-ad policy violations.
- Live ads can be enabled for a release build with `VITE_USE_LIVE_ADS=true`.
- `AdMob.initialize()` now uses the same test/live mode as the rewarded ad request.
- Rewarded-ad screens continue to grant rewards only after the native Rewarded event confirms completion.
