# V47 — 3D Tarot / Katina / Melek Kartları

- Tarot, Katina ve Melek Kartları tek bir ThreeCardFortunePage tasarımında birleşir.
- Her deste 12 gerçek görsel kart kullanır: `/public/generated-cards/{tarot|katina|angel}-01..12.jpg`.
- Kullanıcı 12 karttan en fazla 3 kart seçer; tam 3 seçimden sonra FALIMA BAK aktif olur.
- Seçilen kartlar üstteki 3D seçim alanında gösterilir.
- Kartlarda perspektif, derinlik, iç gölge, altın çerçeve ve seçilme parıltısı bulunur.
- Eski ikon/SVG kart bileşenleri bu üç sayfada kullanılmaz.
