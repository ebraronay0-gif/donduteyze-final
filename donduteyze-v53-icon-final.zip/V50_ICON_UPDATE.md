# V50 — Döndü Teyze launcher icon update

- Replaced the Android launcher icon source with the approved Döndü Teyze 3D fortune-teller artwork.
- Updated `resources/icon.png`, `resources/launcher-icon-v23.png`, and `resources/launcher-icon-final.png`.
- The GitHub Android workflow forces the generated Android manifest to use `@mipmap/ic_donduteyze_v23` and `@mipmap/ic_donduteyze_v23_round`.
- The workflow generates mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi launcher assets and an Android 8+ adaptive icon, so the icon is not left as the default Capacitor icon.
