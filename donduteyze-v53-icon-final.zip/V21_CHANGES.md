# V21 – Stabilite, Reklam ve Falcı Mesajlaşması

- Falcı seçme ekranı: 4 yorumcu, seçim başına 70 kredi.
- Falcı seçimi sonrası otomatik mesaj oturumu; admin falcı sohbet paneline bağlanır.
- Canlı destek ile falcı mesajlaşması ayrıldı.
- Ödüllü reklam akışı native Rewarded event/ödül sonucuna bağlandı; reklam başarısızsa sessizce kaybolmak yerine yeniden deneme ekranı gösterilir.
- Burç, Bugünün Köşesi ve Döndü Dostum günlük ödülleri reklam akışına bağlandı.
- Çarkıfelek, zar, çekiliş ve gece oyunu için günlük oyun hakkı 1'e çekildi.
- Günlük seri altında 7 günlük hediye görünümü eklendi.
- Kredi Kazan ekranındaki 4 reklam alanı daha belirgin ödül görselleriyle yenilendi.
- Burç sayfasına alt banner reklam eklendi.
- Ana sayfa Bugünün Köşesi kartlarına kısa önizleme metinleri eklendi.
- Android launcher ikonu v21 kaynak adıyla zorunlu uygulanacak şekilde yenilendi; adaptive icon ve legacy density ikonları üretilecek.
- Android versionCode 21 / versionName 1.0.21.
