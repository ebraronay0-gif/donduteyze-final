# Döndü Teyze V17

- Ana sayfada 7 fal kartı: Kahve, Tarot, Yıldız, Rüya, El, Katina, Yüz.
- Yıldız Falı yeniden ana sayfaya eklendi ve ayrı sayfasına bağlandı.
- El/Katina/Yüz kartları diğer fal kartlarıyla aynı görsel kart sistemi ve efektleri kullanıyor.
- Ana sayfa reklamı kartların altında, ortalanmış biçimde gösteriliyor.
- Günlük / Günlüklerim kartlarında taşma düzeltildi.
- Yorumcularımıza Fal Baktır alanında fiyat/satın alma ekranı kaldırıldı; fal seçimi doğrudan ilgili fal sayfasına gidiyor.
- Çarkıfelek ve Zar reklam sonrası ödül akışı korunuyor; Çekiliş sayfasına günlük +2 kredi reklam ödülü eklendi.
- Kredi hareketleri merkezi `credits-updated` olayıyla anlık başlık güncellemesine bağlandı.
- Android launcher ikonu V17 kaynak adıyla yeniden uygulanıyor; eski Capacitor ikonları temizleniyor ve uygulama sürümü 1.0.17 / versionCode 17 olarak yükseltiliyor.
- Tarayıcı/apple touch icon yanlış dosya referansı düzeltilerek `/icon.png` yapıldı.
