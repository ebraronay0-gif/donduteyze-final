# V28 — Referans 3D Tasarım

- Ana sayfadaki 9 fal kartı, onaylanan mor-altın 3D referans tasarımın aynı görsel dilinden kırpılmış yeni görsellerle güncellendi.
- Ana sayfa üst görseli yeni referans hero görseline taşındı.
- 15 KREDİ rozetleri kaldırıldı; kart görsellerindeki referans tasarım korunarak kartlar daha temiz hale getirildi.
- El, yüz, katina, su ve melek kartları artık kahve/tarot/yıldız kartlarıyla aynı görsel aile içinde.
- Su Falı sayfasındaki interaktif kase görseli yeni 3D referans kase görseliyle değiştirildi; parmakla karıştırma, enerji ilerlemesi, reklam ve AI gönderim akışı korunuyor.
- V27 unified tema üzerine referans-grade 3D kart çerçevesi ve hover/touch derinlik efektleri eklendi.
- Mevcut kredi, reklam, AI, navigasyon ve günlük özelliklerinin işleyişine müdahale edilmedi.
