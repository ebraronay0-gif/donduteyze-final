# V45 — Startup error + launcher icon fix

- Fixed the startup crash `Cannot access 'isAdminRoute' before initialization` in `src/App.tsx`.
- All React state declarations now run before effects that reference them.
- Bumped app version to 1.0.33.
- Added `resources/icon.png` as the canonical launcher icon source for Capacitor Assets generation.
- Keep the existing web icon at `public/icon.png`.

Build steps for the native app:
1. `npm install`
2. `npx cap add android` (only if the Android project does not exist)
3. `npx capacitor-assets generate --android`
4. `npm run cap:sync`
5. `cd android && ./gradlew assembleDebug`
