# Döndü Teyze V19

- Benim Evrenim hub: Döndü Teyze’nin Çantası, Sürpriz Sandığı, Arkadaşına Fal Gönder, Burç Rehberi, Rozet Koleksiyonu ve günlük seri.
- Çanta günlük sürprizi; kredi ödülü kredi cüzdanına `addCredits` ile işlenir.
- Reklamlı ödül sandığı AdMob Rewarded akışını kullanır; ödül yalnız tamamlanan reklam callback’inde verilir.
- Rozetler: ilk fal, günlük, pet, şans oyunu, gece oyunu.
- Burçlar: Bugün/Aşk/Para/Kariyer/Şans odaklı alternatif görünüm, şans sayısı/saat/renk.
- Günlük: ruh hali seçimi ve aylık özet bölümü.
- Ana sayfada Benim Evrenim için tek, sade bir giriş kartı; mevcut fal kartları ve NOW BAR korunur.
- Sürüm 1.0.19.
