# V35 – Galeriden Fotoğraf Yükleme

- Kahve falı, el falı ve ortak fotoğraflı fal ekranlarında kamera butonunun hemen altına ayrı **Fotoğraf Yükle** butonu eklendi.
- Galeri seçimi kamera yakalama akışından ayrıldı; kullanıcı doğrudan cihaz galerisinden görsel seçebiliyor.
- Yüz falı sayfasına da kamera ve galeri için ayrı, görünür butonlar eklendi.
- Seçilen fotoğraf mevcut fal gönderme/AI analiz akışına aynı şekilde aktarılıyor.
