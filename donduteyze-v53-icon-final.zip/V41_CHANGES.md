# V41 Changes
- Premium checkout no longer forces login; it creates a Supabase anonymous identity for guest purchases.
- Admin Live Chat and Support Chat are stacked vertically for app-like messaging and clear user identity display.
- Added admin notification hooks: foreground web notification when a new unread user message arrives.
- Added native push registration scaffold and `push_tokens` migration. Production background phone notifications require installing/configuring Capacitor Push Notifications plus FCM (Android) / APNs (iOS) credentials and a Supabase Edge Function/trigger to send pushes on new user messages.
- Google Play / App Store purchases must use the platform billing system for digital goods/services unless an applicable exception/program applies.
