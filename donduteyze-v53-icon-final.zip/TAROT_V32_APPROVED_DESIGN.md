# Tarot page redesign

- Tarot page redesigned around the approved 12-card visual concept.
- Exactly 12 selectable cards are shown in a 3x4 layout on mobile/desktop.
- User can select exactly 3 cards.
- Selected cards are shown in a dedicated "Seçilen Kartlar" area with pick order.
- "Falımı Bak" stays disabled until 3 cards are selected.
- Existing rewarded-ad flow remains before submission.
- Existing `submitFortune({ fortuneType: 'tarot' })` flow is preserved, including the hidden preparation/ready-at behavior.
- No 4-minute duration is displayed anywhere on the Tarot page.
- Tarot card visual language is unified with the app: deep purple, gold, cosmic particles, luminous borders and 3D-style depth.
- Added `public/tarot-design-reference.png` as the approved visual reference.
