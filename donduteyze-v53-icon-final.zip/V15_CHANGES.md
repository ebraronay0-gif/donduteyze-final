# Döndü Teyze V15

- Launcher icon now uses a unique `ic_donduteyze_gold` resource and is applied after Capacitor sync, after deleting generated `ic_launcher` resources.
- Kariyer opens the same glass modal style as Aşk/Burç.
- Added image-based El Falı, Katina Falı and Yüz Falı cards to the top six-card grid.
- Removed the lower extra-fortune grid and replaced it with Günlük / Günlüklerim.
- Added local diary storage with date/time on every saved entry.
- Added 3D-style Çarkıfelek, Zar Oyunu and Çekiliş visuals.
- Redesigned the bottom navigation with custom 3D-style SVG visuals for Döndü Teyze, Fallarım, Kredi Kazan, Burçlar and Canlı Destek.
- Redesigned the commentator CTA with Döndü Teyze artwork.
- Live commentator purchase no longer sends the user to a login page; it attempts Supabase anonymous authentication when needed.
- Added explicit manual Yorum Tarihi / Yorum Saati fields to Yıldız Falı and include them in the AI request.
- Top fortune cards display `15 KREDİ`.
