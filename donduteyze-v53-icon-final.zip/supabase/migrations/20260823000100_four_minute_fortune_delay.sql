-- Standardize all new fortune readings on a four-minute preparation window.
ALTER TABLE fortune_readings
  ALTER COLUMN ready_at SET DEFAULT (now() + interval '4 minutes');
